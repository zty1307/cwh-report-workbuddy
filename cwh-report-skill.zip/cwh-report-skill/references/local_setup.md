# 在 WorkBuddy 安装和检查

Windows 和 macOS 共用此包。使用者需要已登录 WorkBuddy，并能调用所选模型和公开搜索工具。从公开安装页下载 ZIP，也可以直接接收安装包。

1. 把含 `SKILL.md` 的文件夹解压到当前用户的 `.workbuddy/skills/cwh-report-skill`。检查只有一层同名文件夹。有旧版时先备份。安装完成后在 WorkBuddy 新对话里调用本技能。
2. 使用 Python 3.11 或更高版本。可优先使用 WorkBuddy 的 Python。Windows 常见位置是用户目录的 `.workbuddy/binaries/python/envs/default/Scripts/python.exe`，macOS 可查找对应环境下的 `bin/python3`。建议为本技能建立单独的虚拟环境，并用该环境的 Python 执行 `-m pip install -r requirements.txt`。
3. 运行 `python scripts/run_with_workbuddy.py --check`。程序查找 WorkBuddy 和 Node.js。如未自动找到，可设置 `CWH_WORKBUDDY_CLI` 和 `CWH_NODE_PATH`。WorkBuddy 自带 CLI 在应用资源的 `app.asar.unpacked/cli/bin/codebuddy`，macOS 的应用资源位于 WorkBuddy.app 的 Contents/Resources。
4. 表格逐页检查可使用 LibreOffice，Windows 也支持桌面 Excel；装有兼容 Codex 渲染组件时可复用该组件。LibreOffice 可用 `CWH_SOFFICE` 指定可执行文件。仅装 Mac 版 Excel 的机器请先检查是否已有上述渲染组件。
5. 模板中的正式图表使用微软雅黑常规和粗体。优先使用已安装的正版字体。若未自动定位，可分别用 `CWH_CHART_FONT` 和 `CWH_CHART_BOLD_FONT` 指定字体文件路径。词云的中文字体随包提供。
6. 环境检查通过后，再提供本期监测文件。在新对话里报告实际完成情况和成品位置。正式数据和输出保存在使用者指定的本机任务目录。
