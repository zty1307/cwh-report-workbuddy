# CWH formal report rules

These rules combine earlier mentor-report measurements with a comparative review of three unrelated periods (May, early July and late July). Baselines are evaluation material, not production inputs or a source of current facts.

The formal report must follow this stable structure. Do not invent a new chapter layout unless the user explicitly asks for a non-formal analysis draft.

The machine-readable source of truth is the shared merge of `config/formal_writing_rules.v1.json` and `config/editorial_template.v1.json`. The latter contains the user's approved fixed wording and configurable chair default; it is an editorial profile, not a source of measured facts. `scripts/normalize_cwh_analysis.py` assembles viewpoint paragraphs from verified atomic claims; the model does not improvise the final attribution, order or punctuation. Preserve the human-reviewed source Word, import only its approved hash, and never print its editing instructions in the report.

An exact statement in a source does not automatically belong to that source's publisher as an independent viewpoint. Pure retelling of meeting requirements remains meeting facts, even if “要” is paraphrased as “需”; use only the identified speaker's additional reasoning. Preserve distinctions between a proposal, a draft passed at the meeting, a published regulation, a local pilot and nationwide implementation. Overseas raw-review and supplemental-search summaries share the configured interpretation rule: policy judgment plus source-supported reasoning, not an article synopsis or review-process explanation. Keep qualifications in full; renderers must not cut a reviewed summary at an arbitrary character boundary.

An independently reviewed explicit meeting date may be mapped to the same frozen article's first 2,000 characters, which the reviewer receives for reference disambiguation. The script records the exact dated meeting identity and source offsets; it tolerates only a comma and the literal linking verbs 召开/举行. This permits context-supported identity expansion, not borrowing other numbers or arguments from elsewhere in the article. Every other number still requires the selected excerpt; snapshot integrity and independent semantic review remain mandatory.

## Typography retained from the earlier measured mentor reports

- Title: `华文中宋`, 22 pt, bold, centered, no first-line indent.
- Level 1 headings such as `一、舆情传播情况`: `黑体`, 16 pt, not additionally bolded, first-line indent 2 characters.
- Level 2 headings such as `（一）总事件传播情况`: `楷体_GB2312`, 16 pt, bold, first-line indent 2 characters.
- Viewpoint-group headings such as `1.建议……`: `仿宋_GB2312`, 16 pt, bold, first-line indent 2 characters.
- Body: `仿宋_GB2312`, 16 pt, first-line indent 2 characters.
- Subtopic and overseas tables: `微软雅黑`, 11 pt; header rows bold and centered.
- WeChat TOP table: `仿宋`, 12 pt; header rows bold and centered.

Apply these fonts directly to heading runs as well as to paragraph styles. Do not rely only on Word's built-in `Heading 1/2/3` theme fonts, because Word may substitute `+中文标题` or `MS Gothic`.

## Title and lead

Title:

```text
X月X日国务院常务会议舆情综述
```

Opening paragraph:

```text
国务院总理{chair_name}X月X日主持召开国务院常务会议，{agenda_topics}。本次国务院常务会议舆情传播情况如下：
```

Use the original current agenda wording as much as possible. The number of subtopics is dynamic. Sourced `meeting.chair_name/chair_source` overrides the explicitly approved editorial chair default. For other terms, supply current metadata or change the configuration; the chair is not an algorithm constant. Word and Markdown call the same opening helper and audit editorial provenance separately from source verification.

The pipeline passes its reviewed `meeting_context.json` to rendering. Reuse its agenda summary only after rechecking source hash, meeting date, exact topic order, topic anchors and continuous source wording (ignoring layout punctuation). Remove a repeated meeting/chair introduction before filling the fixed opening. This adds no model call and no baseline facts. Missing or nonliteral context retains the existing topic-list opening with an explicit `meeting_lead` audit; it does not block other deliverables or silently invent agenda verbs.

## Fixed sentence library

Use these as stable sentence frames and replace only bracketed values:

```text
本次常务会引发境内外媒体广泛报道，境内外传播总量约{total}条{supported_focus_sentence}。{supported_peak_sentence}
境内主流媒体如人民网、新华网、央视网等均在显著位置刊文，共有相关报道{domestic_count}条。
新媒体中，微信公众平台相关信息{wechat_count}条、微博相关信息{weibo_count}条，视频号相关信息{video_count}条，新闻客户端、论坛等渠道共有相关信息{other_count}条。
境外媒体{supported_source_examples}共有相关报道（含转载）{overseas_count}条。具体主流报道情况见附表。
```

The renderer fills numerical fields from workbook facts. Include a peak only with dated nonzero trend observations and overseas examples only from actual accepted rows. Broad coverage and domestic prominent-placement wording are user-approved editorial text, not host-verified source findings. Never infer counts or modify source review from those phrases. For domestic viewpoints, support both a single-cluster paragraph and a multi-cluster `一是、二是……` pattern. Use the configured stance verbs only when supported by the evidence cluster.

For overseas coverage, first run an AI relevance review and exclude rows that only overlap with an agenda topic but do not report or interpret the meeting. Classify eligible rows by article body, then use the factual lead and a separate interpretive paragraph specified below. Do not number report categories:

```text
数据周期内，境外媒体以事实性报道为主。如{examples}等，少量解读如下：
{reviewed_interpretive_prose}
```

Use this majority lead only when factual reports exceed half of the eligible reviewed rows. Mixed coverage instead uses `境外媒体报道中包括事实性报道` and `相关解读如下`. If there is no interpretation, use `，暂无评论性文章。` instead. Do not force a missing category into the report. Negative wording, criticism or a crawler-supplied tag alone is not proof of `借题炒作/风险解读`.

## 一、舆情传播情况

This chapter has exactly two sub-sections.

### （一）总事件传播情况

Required content:

- Overall domestic and overseas spread volume.
- Any main focus statement must be grounded in the current evidence, never a fixed name or quoted historical title.
- Peak date only when supported by dated nonzero workbook trend data.
- Domestic mainstream media volume.
- WeChat public-account volume.
- Weibo volume.
- Video-account volume.
- News client/forum/other channel volume.
- Overseas report volume.
- End by pointing to the appendix: `具体主流报道情况见附表。`

Numerical propagation facts must use the monitoring workbook's scope. Missing required workbook totals are a blocker; do not replace full-volume counts with a search sample. Keep limitations in `cwh_audit.json`; do not put hollow placeholders such as `需补充数据` in the formal report body.

### （二）子议题传播情况

Trend and subtopic-volume charts always use the baseline-locked report visual templates, even when a monitoring image exists. Original images remain untouched source/audit assets, not report styling authority. The reviewed word cloud remains unchanged. See `references/word_fill_in_template.md` for exact titles, geometry, color, typography and variable-data slots.

Bind both template-generated PNGs to current meeting date, totals, trend/topic values and style-configuration hashes. DOCX acceptance requires their actual image hashes and manifest to match; a historical monitoring image or older approximate fallback does not satisfy the new visual contract. Word and workbench use the same report images.

Use one table. Required columns:

- 序号
- 标题
- 境内主流媒体
- 新媒体
- 境外媒体
- 总量
- 网民情感：正面 / 中立 / 负面

The table must be generated for all detected subtopics, not hard-coded to four items. Always retain the nine-column, two-header-row baseline table from `templates/topic_table.xml`; missing reviewed sentiment leaves blank cells, never drops the three columns or invents ratios. Table paragraphs have explicit zero indents so body formatting cannot break numeric cells.
Keep the full system subtopic titles in this table, including action wording such as `听取`、`研究`、`审议通过` and the full policy name. Use 11 pt table text; do not shorten titles merely to make the table fit one page.

## 二、境内舆论情况

This chapter has exactly three sub-sections.

### （一）境内媒体自媒体情况

Organize by subtopic or stable viewpoint group. Use numbered top-level items:

```text
1.建议……
2.认可……
3.肯定……
```

Before writing, build an audited candidate pool from the priority source registry and open-web discovery. The registry is not an allowlist. Follow the selected profile in `research_plan.json`: bounded profiles use grouped lanes;40m/60m allow at most10queries per topic,45m allocates10 with up to4 additional targeted queries for weak raw topics. Full-page caps are18 in40m/45m and24 in60m; see adaptive_web_research.md. Stop after lane coverage plus one zero-new round or budget exhaustion; `exhaustive` searches individual required sources and requires two zero-new rounds. Keep a decision for every result actually reviewed within scope. Caps are limits, not mandatory work quotas.

In bounded mode, normally select 4-6 attributed excerpts across 2-3 distinct judgments per topic. These are soft editorial references, not independent-person quotas or hard deletion limits. Additional excerpts need an indispensable new judgment, condition, suggestion or dissent; thin topics retain less without padding. The existing 12-subject and six-group safety caps remain, not targets. Keep additional valid material as audited reserves. Do not shrink discovery or full-text reading. Whole-report excerpt and paragraph totals depend on current topics and evidence, never historical totals. Exhaustive mode maps every eligible independent voice into prose.

Selection audit fields describe actual coverage and editorial choices, not corroboration requirements. A single attributable, substantive judgment is valid evidence and can stand alone when the topic has only one body paragraph. Multiple body paragraphs require numbered groups with at least two distinct sources per group under the current user-approved layout contract. Do not infer unsupported claims, missing original reasoning, or low credibility from subject counts. Attempt native regrouping before freezing within the existing synthesis budget; do not let the host silently discard thin groups or retain only the first group. An unresolved selection remains explicitly incomplete, and only independently verified claims may enter available-with-gaps prose; the two-source formal quality gate remains unchanged. Claims explicitly not selected by the author remain complete audited reserves. Keep count bookkeeping and mandatory independent source-support review separate.

Normal interpretive headings begin with an evidence-supported stance or action verb such as `建议、认可、肯定、认为、期待、希望、支持、呼吁、质疑、担忧`. Remove empty wrappers such as `舆论关注` and do not use the first cluster's judgment in place of the full policy scope. If a topic lacks independently interpretable evidence, keep its original topic heading and the configured available-content gap notice, not a factual digest disguised as a viewpoint. When current host-recompiled heading review rejects a proposed title, its neutral topic/report fallback is allowed for available-content delivery; it does not certify a clear interpretive heading or erase outstanding strict writing-quality issues.

The attitude verb is a conclusion from evidence, not a positivity template. Use `肯定/认可/支持` only when the source itself expresses approval, `建议/期待/呼吁` for proposals, `认为/指出` for analytical judgment, and `质疑/担忧` for criticism or risk. Do not rewrite neutral analysis as praise merely to imitate a historical report.

Use the configured `viewpoint.selection_rule` before freezing claims: retain different substantive judgments actually present in the read sources, rather than letting several broad-meaning statements crowd out distinct mechanisms, conditions, risk boundaries or proposals. These are comparison dimensions, not mandatory topic columns. One article can provide multiple independently attributed voices. A cluster must have a genuinely shared judgment; different mechanisms cannot acquire the first speaker's causal chain merely by sharing a policy topic. `viewpoint.heading_support_rule` applies in the author and independent heading review, without an extra whole-report rewriting pass.

The common writing unit across baselines is a concrete judgment with its source-supported reason, mechanism, condition or suggestion, not a report introduction. Use `viewpoint.claim_composition_rule` and `viewpoint.cluster_structure_rule` in both author transports. Retain specific policy objects, implementation actors and effect boundaries; do not compress actual methods into abstract phrases such as “improve mechanisms”. Suggestions remain suggestions; pending drafts remain pending. Order clusters for understanding, not by outlet class. Do not inherit baseline dates, ratios, fixed expert names, measured positive sentiment or rhetorical padding. The only fixed editorial defaults are those explicitly approved in `config/editorial_template.v1.json`; they do not alter evidence or measurements. Different comment reactions may coexist within a topic; the current grouping contract is not inferred from one baseline's numbered count.

Inside a viewpoint group, use dynamically generated `一是、二是……` when there are multiple viewpoint clusters; there is no fixed five- or eight-group truncation. Each numbered subpoint requires two distinct sources under the current user-approved layout contract. A single strong source is valid evidence, not a reason to invent a second voice; use an unnumbered paragraph for a sole mature group, or mark the unfinished multi-group layout as an editorial gap. Normal interpretive cluster headings use the same source-grounded stance rule as the top-level heading; do not write a bare factual deployment as an independent judgment. A host-audited neutral fallback can preserve available content after rejected heading review, but remains an unresolved writing-quality issue, not a certified common judgment. Pure meeting-action facts do not qualify as independent interpretive voices.

Every claim should include evidence sources such as experts, media, institutions, or public accounts:

境内媒体自媒体观点执行 `viewpoint.speaker_eligibility_rule` 和 `viewpoint.attribution_body_rule`：具名个人须有原文可核实、与议题相关的机构、职务和姓名；普通个人、普通网友、匿名个人及仅自报经历或工龄者不作本节样本，也不改归转载账号。真实网友评论仍按独立网民章节规则审核。账号自身观点用平台类型和账号全名；账号引述专家时归专家。正文直接写“核实的机构＋职务＋姓名＋归因动词＋观点”或“媒体／平台账号全名＋归因动词＋观点”，省去采访过程。`formal_claim` 直接写观点，不重复当前主体姓名、账号名或栏目抬头。完整原文、采访渠道和原始身份保留在证据审计中；不补造缺失身份。明确重复的账号前缀可在冻结前规范化并保存作者原稿；冻结后不靠渲染删改绕过核查。

```text
某专家称……
某媒体报道称……
微信公众号“某某”称……
```

Avoid unsupported generic wording such as `媒体普遍认为` unless evidence is cited.
Formal Markdown and Word must not append `样本来源：……`、`公开网络补证`、`原始报道汇总` or any link-list paragraph after a viewpoint. Put the verified original link on the corresponding dashboard evidence card and keep source metadata in structured audit data. Formal body prose consists only of concrete attributed claims.
Write every independent voice as `完整机构/职务/姓名+称/指出/建议等+具体观点`; when no named person is available, write `媒体/平台/自媒体账号全名+称/指出/建议等+具体观点`. Neutral added attribution defaults to 称, separate from the evidence-supported attitude verb in headings. Prohibit vague aggregation such as `报道汇集刘某、伍某、严某等对……的分析` or `多家媒体关注……`; split genuinely distinct speakers into separate attributed sentences within the same group paragraph, not separate unnumbered paragraphs. If several URLs reproduce the same speaker and same claim, render that claim once and keep the other URLs as duplicate audit records.

Do not erase evidence by speaker name alone. Preserve distinct supported judgments with their own source mappings in the workbench. For formal prose, the current user-approved contract takes precedence: one source at most twice in the report, only across different topics and with different useful judgments. Within a topic select the most useful supported claim rather than repeating that source in separate clusters. This is an editorial selection constraint, not proof that historical baselines never repeat sources. Never silently discard retained evidence or merge unreviewed meanings.

Authoring, synthesis, local repair and independent review share the configured editorial eligibility criteria. Textual support does not itself establish suitability for the report; assess actual policy analysis, not financial vocabulary or the source channel. Following reviewer narrowing or exclusion, recheck headings against the complete retained, independently reviewed claims only. Original excerpts remain in the evidence audit but must not reintroduce a removed assertion into a heading. Missing or invalid heading review uses an explicitly audited neutral display fallback while preserving the original draft; it is not a successful semantic heading review.

For self-media, the formal display name includes the platform type. Derive it from the evidence URL when possible: `微信公众号“账号”称`、`头条号“账号”称`、`百家号“账号”称`、`微博账号“账号”称`; if the platform cannot be determined, use `自媒体账号“账号”称`. Keep the raw account name unchanged in evidence data. Added neutral attribution uses `称` for both people and media/self-media; this display rule may normalize neutral 认为/表示/说 prefixes, but never rewrites attribution already embedded in a frozen literal claim or specific suggestions, forecasts, approval or criticism. Do not mechanically convert headings to 称 or neutral views to praise.

Headings are editorial conclusions, not stitched summaries. A top-level viewpoint heading should normally contain 12-26 Chinese characters and a cluster heading 10-24. Each heading expresses one central judgment; do not join different clusters with `并/与/及`. Choose `认可、肯定、建议、期待、希望、支持、质疑、担忧、强调、认为` according to the evidence. Variation is desirable only when the source stance supports it; never turn neutral analysis into approval merely to vary the verb.
For a mature multi-source cluster, normally use two complementary selected voices; a substantive third source may add information. A single voice can stand alone only in the sole-group, single-paragraph layout. Each claim carries one central attributed judgment, normally 50-120 characters, preferably 80-100, maximum 150 (punctuation included; attribution and whitespace excluded), with its necessary reasoning and conditions. Edit overlong material against the full source before freezing and independently review it; retain unresolved full claims as audited reserves, never cut frozen text. All sources of one cluster stay in one paragraph, with consecutive 一是/二是 prefixes when the topic has multiple paragraphs. Neither the old 300-character threshold nor a two-sample count may create an unnumbered continuation. Different judgments remain separately mapped in evidence; selection obeys the current source-reuse rule. Cluster count follows actual judgments, not a fixed four-angle ceiling. Do not compress several sources into an anonymous summary or inflate page count with repeated wording.

The shared `viewpoint.composition_frames`, `claim_unit_rule`, `paragraph_pairing_rule` and `paragraph_layout_rule` are injected into the relevant model tasks. Use a judgment-plus-reason, effect-with-condition, obstacle-and-suggestion, or change-and-meaning frame only when the current full source supports its slots. They are alternatives, not mandatory angles. Pair voices around a genuinely shared judgment, preferring complementary explanation over repeated praise. One well-supported voice can stand alone in a sole-group topic with its recorded exception, not as a numbered singleton in a multi-group topic. Do not invent agreement, a counterargument, a causal bridge, or a second voice to fit the frame. Recheck group counts after independent review; a late shortfall remains an editorial gap, never a reason to hide all numbering or claim formal quality. Examples are fictitious teaching material and never source evidence; baseline accounts, dates and conclusions are not production lookup requirements.

Source fidelity is not a certificate that the source's own reasoning is correct. Apply `source_reasoning_quality_rule` to visible arithmetic contradictions, mixed units, assumptions presented as facts and unsupported policy-stage shifts. Record the specific concern instead of replacing the author's figures or inventing a better argument. Preserve separately supported suggestions, including criticism. The reviewer must distinguish exact textual support from formal-use eligibility; adding "the author thinks" cannot cure an obviously faulty premise. This is a bounded check of the supplied evidence, not a claim to have independently fact-checked every background statement on the web.
The shared executable density gate requires two distinct speaking subjects and at least 120 Chinese characters, or a `thin_cluster_exception` containing non-empty `reason`, `search_evidence` and `reviewed_by`. Both draft validation and final auditing use this rule. The exception is retained in the audit and does not waive the minimum quality of each claim, original-source mapping or independent semantic review. Repeated URLs, repeated speakers and repeated attribution verbs do not increase independent-voice count.
Bold each `一是/二是……` conclusion and the named source plus attribution verb (`某专家认为`、`某媒体报道称`、`微信公众号“某某”称`).

Apply the following source and wording rules to every meeting:

- Deduplicate the same subject's same judgment, not the subject's name. A person, institution or media/self-media source can supply different substantive judgments to the appropriate clusters; retain their separate original mappings and count the subject once in topic-level independent-source totals. The host never merges unreviewed meanings or changes frozen claims to create a fuller passage. Cross-topic reuse requires separate directly relevant arguments, not repetitive coverage.
- Distinguish the speaking subject exactly. When the publication itself gives analysis or advice, write `某媒体认为/称/建议`. When the article quotes a verified person, write the person's full verified institution, title and name. Under the current editorial contract, unnamed-source interpretations remain reserve evidence, not formal `援引业内人士观点称` prose. Do not invent a name or reattribute an unnamed person's judgment to the publisher.
- Use the source passage as the wording anchor. Lightly trim repetition and connect clauses for readability, but preserve the original claim's key nouns, verbs, scope, qualifications, examples and policy mechanism. Do not replace a specific source statement with a broader AI-created causal conclusion.
- Check each speaking subject separately, including several experts quoted by the same article. A single attributed proposition should normally contain about 50-120 characters (punctuation included; attribution and whitespace excluded) of substantive content. A proposition with fewer than 30 Chinese characters fails the formal gate: return to the original passage to include its reasoning, mechanism, condition or example, combine a related passage from the same source, or omit that voice. Do not pad a weak sentence with generic policy language. Do not count noun phrases such as `宏观分析人士` or `政策解读文章` as attribution verbs, and do not merge several short expert statements into one long evidence row to pass the threshold.
- Public-article TOP ranking is not a writing-evidence filter. Use the complete controller corpus index to choose bounded full-text reads regardless of appendix read rank; retain unread IDs as deferred, not reviewed or excluded. Exhaustive mode reads the entire corpus. When one article quotes several named speakers, extract and assess each voice separately. This rule is reusable across meetings and must not be relaxed or narrowed to imitate one benchmark.
- Prefer named experts, professional institutions and media judgments that explain a policy mechanism, condition, effect boundary or concrete suggestion. Self-media remains eligible, but exclude commercial self-promotion for its own company/product, tangential promotion of an activity or service, and text whose substance is only a slogan, pun, metaphor or generic growth forecast. These are editorial-use exclusions, not deletions from the evidence pool.
- Tangential promotion, market-only pitches and slogan-only reasoning require semantic assessment of actual substance. Historical catchphrases are not general-purpose exclusion regexes. Financial or consumption analysis with a specific policy mechanism remains eligible; a slogan embedded in genuine reasoning does not by itself invalidate the entire claim.
- Period prose may cite a public-web page only when its source-page timestamp has been preserved and verified inside the monitoring window. Exclude later pages even when their wording closely matches the desired report; do not backdate them from search snippets or article subject matter.
- If a top-level subtopic has only one mature cluster, write the top-level heading and its evidence paragraph directly. Do not create a lone `一是` without a `二是`.

### （二）网民评论情况

Lead sentence:

```text
网民有关本次国务院常务会议讨论的情感属性以积极正面和客观中立为主，主要有{stance_summaries}等。主要评论如下：
```

The lead uses the first complete clause of each reviewed group heading. The configured 22-character length is an authoring recommendation, never a renderer cutoff: do not sever a word to meet it. Keep the full reviewed heading in the numbered body item. Selection uses the shared `comments.selection_quality_rule`: a long abstract endorsement is not automatically a substantive quotation. Rejecting it for formal selection must not change the frozen sentiment label or denominator; never invent a specific heading to conceal an empty original judgment.

The compiled comment host independently reviews only selected original quotations and their headings in a fresh serial context, within the existing stage clock (reserve 35 percent, capped at 90 seconds, no parallel agent). Unused author time may flow into that review up to the same cap; the stage deadline is unchanged. It cannot relabel, rewrite or add comments. A rejected or uncompleted selection remains in the audit and sentiment corpus but not the formal quotations; available-content delivery continues with the gap marked. Empty selection skips this call.

Bounded collection reviews up to the configured 30 already captured rows per topic and 300 overall, rather than a per-topic cap below the unchanged 20-effective-comment percentage gate. No additional collection round is implied. All omitted rows remain auditable as deferred by sampling, not unrelated. A cap is not a quota: never invent comments, force labels or lower the readiness denominator. Describe sentiment as applying to the reviewed collected-comment sample, not the entire population.

Then group representative raw comments:

Search all workbook topics before selection. Use the configured per-topic query limit: four for `bounded_40m`, six for `bounded_60m`; both retain at most 30 candidates, then select 2-3 traceable comments for each ready topic. `exhaustive` may continue to saturation. Preserve a topic-by-platform matrix with exclusions and blockers. Display all current subtopics in input order; a topic without approved quotations gets the fixed missing-topic notice, not a fabricated stance or quote. Fixed editorial lead wording must not alter measured sentiment labels, ratios or denominators.

```text
一是认可……并期待……。网民称，“……”“……”。
二是质疑……并建议……。网民称，“……”“……”。
```

Use real collected comments only. Preserve original wording, with only light formatting cleanup. Keep platform/account/time/link/interaction metadata in structured data and appendices.
Every selected comment must have a completed AI formal-use review. The group heading must summarize the actual stance, expectation, criticism, reason or concrete suggestion shared by the quoted comments. Never fall back to `关注+议题名称`; a missing reviewed heading blocks formal rendering rather than triggering a generic title.

Comment discovery consumes current input policy aliases or, when no external metadata was supplied, this job's generated `artifacts/run_metadata.json`. Check topic names and order against the current research plan and retain the metadata hash. Invalid aliases are isolated with a reason while original-topic searches remain available; they must not silently label another period or prevent comment collection. Discovering raw comments is not formal-use approval.
Apply `comments.heading_summary_rule`: use a natural sentence about the actual object and opinion, not an abstract noun string copied from the quote with an added attitude verb. A genuine comment can remain in the sentiment denominator without being a suitable formal quotation. Preserve the original quote exactly; easier-to-read headings do not permit rewriting it.
Group comments by the actual independently reviewed judgment, not by topic alone. Different reactions to one agenda may form separate numbered items; only same-topic comments with the same reviewed individual `heading` are combined. Models no longer write a redundant `topic_headings` index; the script maps the validated topic number to the current input title for the compatibility CSV column `topic_comment_heading`. Legacy model indexes remain in raw logs but never become prose. Individual headings, quote verdicts, full ID coverage and frozen source identity are still required. Never join different expectations into one long composite heading.

### （三）热词分布情况

Write one explanatory paragraph, not only a word list:

```text
从热词分布来看，“A”“B”“C”等词位居前列，舆论{已审核态度判断}。“D”“E”“F”等词热度较高，舆论{已审核态度判断}。“G”“H”“I”等词备受关注，舆论{已审核态度判断}。此外，“J”“K”“L”等词也受到关注，舆论{已审核态度判断}。
```

Hotwords must be connected back to public attention points and subtopics.
The current approved editorial profile uses the fixed frames above, normally 3–4 reviewed terms per group, up to 5 when useful; do not fill missing words. Treat rank phrases as the user's qualitative editorial convention, not measured new term-frequency values or time-series evidence. The neutral profile remains available when this convention is disabled. Link only actually reviewed judgments, and never infer new agreement from layout or topic totals. When the reviewed focus starts with a stance verb, write `舆论认为/建议/期待……`, not `主要聚焦认为……`. Wordcloud rendering must follow the separately fixed visual contract.

## 三、境外舆论情况

This chapter has exactly two sub-sections:

```text
（一）境外媒体情况
（二）境外网民评论
```

### （一）境外媒体情况

Required content:

- Start with whether overseas media are mainly factual reposts/reports.
- List representative overseas reports with source and title.
- If there is interpretation or risk framing, write it as a separate paragraph after the factual-report sentence.
- If there is no commentary, use `暂无评论性文章。`

An interpretive summary contains only the materially additional impact, mechanism, risk or evaluation found in the article. Do not recap the meeting agenda and do not write meta-summaries such as `报道……并引述……解读……`.

The primary evidence source is the full title and body already contained in the current raw monitoring Excel. Classify every accepted Excel row as factual, interpretive or risk-framed before building the standard workbook, and preserve the classification, reason, confidence and reviewed Simplified Chinese source/title/summary in that workbook. Do not assume interpretation must come from supplemental search, and never silently default an unclassified row to factual. When interpretation exists, use the distribution-dependent transition above and summarize reviewed interpretive reports in the next paragraph. Do not number the report categories.

After every existing Excel row and linked body has been read and classified, run a separate supplemental overseas-media search as a required pass. Use MediaSpider Supervisor `grounding` and/or Agent Reach news/web search, retain the full candidate and saturation audit, and keep X、YouTube and other permitted social rows in `（二）境外网民评论`; never mix social posts into the overseas-media appendix. Skip any platform explicitly paused by the user (currently Reddit) and record that scope limitation. A supplemental news report may affect the overseas count only if it was admitted before workbook finalization through the complete AI overseas review, monitoring-window check and cross-source deduplication. The report renderer itself never patches aggregate counts.

### （二）境外网民评论

Then include:

```text
（二）境外网民评论
境外网民对本次国务院常务会议关注度较低，暂无评论性观点。
```

The fixed notice is explicitly user-approved editorial wording. Preserve the distinction between completed zero-result collection and access failure in the audit; do not certify low population attention from a collection failure. An overseas-media list does not prove social comments were searched. When reviewed comments exist, use evidence-backed groups instead. Keep every `一是、二是……` theme in a separate paragraph, omit account IDs, and quote suitable Chinese translations with platform attribution. Keep provenance, original language, timestamps and URLs in the dashboard and audit.

## 附录

### （一）外媒报道列表（部分）

For relevance, distinguish policy-focused reporting from incidental mentions. A story may focus on the meeting itself or a concrete decision and its direct policy effects. A market roundup whose main subject is price movements or unrelated news is not eligible merely because it cites one meeting decision as a catalyst. Conversely, finance reporting is not categorically excluded when its full-text main line genuinely concerns that decision. The review reason must state this relationship; genre, keyword hits and historical appendix inclusion alone are not proof of eligibility.

Required columns:

- 序号
- 来源
- 报道日期
- 超链接标题

List actual overseas-origin media in this partial appendix. Do not include mainland foreign-language editions such as CGTN, 人民网英文版, 新华社海外版, 中国经济网英文版 or 央视网英文版, although they may remain included in the system's overall overseas count. Render titles as clickable blue underlined hyperlinks.
After relevance review, report-category review, Simplified Chinese normalization and story deduplication, select a representative TOP10 across available categories, regions and subtopics. Keep every accepted row in structured evidence and the dashboard. Use fewer than ten only when the complete eligible set genuinely has fewer than ten rows; missing Simplified Chinese fields are a review-stage error, not a reason to shorten the appendix. In the factual lead, use distinct publishers rather than several stories from one outlet. In the interpretive paragraph, synthesize 1-3 materially distinct angles and remove redundant constructions such as `指出，文章认为`; syndications of one angle are supporting distribution evidence, not separate analytical angles.

Formal Word and Markdown use Simplified Chinese only for overseas outlet names, titles, summaries and appendix cells. Traditional Chinese and foreign-language originals remain traceable in structured data and the dashboard. Traditional-to-Simplified normalization must use the complete OpenCC conversion layer rather than a small character blacklist. Foreign-language translation and converted names, policy terms, numbers and meaning require the overseas AI review before formal rendering.

### （二）传播量较大的公众号文章

Rank publisher families rather than raw rows. Normalize exact account names, then apply only the explicit alias groups in `config/raw_workbook_mapping.json`; retain the highest-read relevant item in each family before TOP10 ranking. Never use fuzzy similarity to merge unrelated accounts or automatically group independent programme accounts under a parent broadcaster.

Required table title:

```text
微信公号文章阅读量TOP
```

Required columns:

- 序号
- 账号
- 标题
- 阅读量
- 在看量

Use the department table appearance: dark navy merged title row and column-header row, white header text, a wide title column, and clickable blue underlined article titles. Preserve display values such as `10万+`/`100000+` when the workbook supplies them.

The table must consume the audited `公众TOP` result, not reconstruct relevance from account names or titles. AI reviews the full body for every maximum-read cutoff candidate, excludes mixed-news roundups and minor-catalyst mentions, deduplicates normalized accounts, ranks by read count and uses `在看` as the secondary key for capped ties. A prior human table is a comparison baseline, not an unexplained override of the current auditable ranking.

## Separation of formal report and audit

Independent compiled review also receives topic and cluster headings, linked to their own evidence IDs. It checks stance, effects versus proposals, scope, conditions and repetitive cluster judgments. Certified replacements are display-only: the host keeps the original headings, actual reviewer run, rationale, supporting IDs and input digest in `research_audit.heading_quality`. Word and workbench use a replacement only while its supporting claims remain independently supported and the audit matches current inputs. Missing, uncertain, malformed or stale heading review produces a quality warning, never a fabricated conclusion or a reason to withhold available files. Explicitly rejected headings without a certified replacement use a neutral topic/report label, not the rejected judgment. Certified factual headings remain neutral instead of gaining an invented positive stance. Expert judgments may be summarized accurately without requiring the exact attribution verb in the source, but factual announcements are not praise. The main check shares the existing reviewer call; overlong headings and clear repetition or multi-center style faults share at most one compact repair call of at most 45 seconds when budget remains. Preserve actual host-run provenance, including prior actual repair runs in an isolated replay; never accept model-invented run IDs. No second full review or extra agent is required.

Filter only exact procedural-only comment phrases configured in `comments.procedural_only_texts` before semantic review. Retain the original text, timestamp, raw pointer and exclusion reason; a substantive comment containing the same words is not removed. Discovery quotas count nonprocedural candidates, not empty forwarding actions. Retain successful zero-result API response bodies and distinguish API-level errors from genuine zero results; neither proves that the topic has no public discussion. Unreviewed or excluded responses never enter the sentiment denominator.

Comment review receives `formal_quote_allowed` and `formal_quote_chars` calculated with the final renderer's exact configured length/format rule. Formatting eligibility is not a semantic verdict or a reason to remove a genuine opinion from the sentiment denominator; ineligible text cannot be shortened or rewritten to evade the limit. Specific neutral questions about applicability, execution or policy meaning can be representative formal quotes. Their headings use inquiry/clarification language, not invented opposition, policy defects or population-wide attention. Distinguish captured rows, sentiment-denominator rows, model-selected formal quotes and quotations actually rendered in Word. For speaker display, remove only an exact duplicated institution prefix when the frozen role-plus-name label repeats it; do not alter the frozen speaker identity or guess new roles.

Hotword prose uses the user-approved fixed frames in `editorial_template.v1.json`, with actual reviewed terms and source-supported stance judgments. These editorial frames do not certify measured word frequencies or temporal trends, and topic propagation volume must not be converted into fabricated term counts. Word and workbench rebuild display paragraphs from the same current atomic evidence; stale preassembled `details` cannot override reviewed claims or retain outdated attribution.

Author claims distinguish `claim_kind=policy_reasoning` from `meeting_action_fact`. Only genuinely substantive mechanisms, conditions, impacts, suggestions or evaluations qualify as independent interpretation. A detailed meeting-action list is still factual reporting, even when republished by a court or government account or fully supported by the source. The host mechanically removes explicitly classified meeting-action facts from formal selection and retains their original classification/text in exclusions. Do not keyword-exclude substantive official implementation guidance or infer missing classifications in legacy responses; this field is not independent quality certification.

Every host-built topic author packet also carries `agenda_topics` from the current research plan. Use the complete current agenda to disambiguate the specific policy being commented on: shared generic words such as law, institution or investment do not justify assigning another agenda's interpretation to a thin topic. Candidate-list membership and full-meeting relevance are not final topic eligibility. The field participates in normal packet hashing/cache invalidation and contains no historical agenda dictionary.

Reading order may prioritize a generic named-professional attribution found in the original body near the current policy name or declared alias. This is a mechanical reading hint, not a speaker identity, independent-voice count or eligibility verdict. The shortlist retains up to 40 source-diversified articles; policy-driven author reading caps are 20 monitoring articles plus ten public pages in `bounded_60m`, 16 plus eight in `bounded_40m`. A specific current-policy title takes reading priority over a generic title containing “解读/专家”, which may be a multi-news or market roundup. Keep all raw IDs and complete original text; unread records remain deferred rather than semantically excluded. Never hard-code people or outlets from benchmark reports into this prioritization.

For bounded available-content delivery, a genuinely empty reviewed topic uses the fixed notice `本轮在监测期内未取得可引用的独立解读，保留该议题的传播数据；这不代表没有相关讨论。` beneath its original topic heading. No fabricated analytical heading or empty `一是` cluster is allowed. Preserve missing-comment/sentiment notices without claiming a zero-result collection when access failed. Keep all existing verified content and the fixed chapter layout. Quantity targets and unfilled sections are audit warnings, not reasons to withhold Word or the workbench; source failures remain auditable and unverified claims never become conclusions.

The formal report body should not contain engineering status blocks such as:

- `正式交付状态`
- `质量门禁`
- `低质量率`
- `目标完成情况`
- internal crawler failure logs

Those belong in `cwh_audit.json` and, if needed, a separate review note.

### 解读资格与原文支持分别核查

纯转述会议要求、既有规划条文、实施安排或统计数据，即使出处真实、细节完整，也不自动构成媒体自身解读。选材必须找到实际发言主体针对本次决策的独立判断、建议或评价；背景事实只支持原文已有判断，不能由模型补出因果或意义。无独立判断时排除并保留缺口，不能收窄成一个事实句后宣称解读通过。原文支持审核和标题审核均不能代替这一选材资格判断。共同规则由config/formal_writing_rules.v1.json的viewpoint.interpretation_eligibility_rule提供，并传入作者提示和各模型任务契约。

正式观点不保留裸“本次会议/此次会议/这次会议/该会议”；按原文明确真实会议名称，相关背景解读不能冒充本次常务会部署。作者先处理；独立审核另获原始标题与最多2000字原文开头，仅用于对象消歧，不能补充截取片段外的论据；宿主最终检查只识别未展开的文字风险，不猜会议身份。原始证据与旧交付不改。

境外summary_cn_simplified是正文观点，review_reason是选材审核理由。两者不能混写：“属会议事实之外新增的分析”“因此纳入”等只放审核理由；正式摘要直接写判断、机制和条件，无原文分析就不补造。

三期共性不是每期都要有外媒评论，而是把事实报道与实际解读分开呈现。每条外媒解读先写原文主体的中心判断，再保留直接支持它的必要依据和条件，通常1—2句、约80—180汉字；长度是建议，不硬截原文条件。项目名、部署清单、投资总额与历年数量不整段搬入观点，不能只加“认为”就把事实转成解读。纯事实仍列在事实报道及附录；没有独立判断时如实留缺口，不为向基准靠齐而补分析。共享规则由overseas.interpretive_summary_rule传入各批原文审核，公众号TOP批不接收境外摘要字段提示。

本期议程明确涉及的其他会议或背景政策的实质解读可以保留，但成文须明确原文实际讨论对象。不能把该原文中的“本次会议”“新增部署”等指称直接移到报告会议，冒称另一场会议的要求是本次报告会议的新决定。独立复核同时收到当前议题、议程组和原始标题，用于讨论对象消歧；标题不代替原文论据，不新增原文未支持的日期、因果或结论。
### 独立复核字段门禁与缓存恢复

合法JSON不代表复核可用。正文审核的rationale必须是非空字符串，空值、错误类型、缺字段和重复/漏掉证据ID不得成为支持认证。宿主在标题返修及原文认证前检查这些字段；字段无效时，只在原独立复核阶段剩余预算允许时，对受影响条目做一次最长45秒的真实补核，保留其原ID、完整冻结摘录及必要对象语境，不重新审核其他正文和标题、不增加全程预算。补核可改变这些条目的判断，但不能给其他旧结论补写理由或重盖运行ID。逐条保留实际审核运行，删改后的认证包也须继承该来源。旧原答、缓存、摘要哈希及真实运行保留；原先标题仍归原始实际标题审核运行。重试仍无效就明确失败，不重复三次读取同一坏缓存当作三次新复核。

超过12条正文观点时，独立原文复核默认按至多8条的小批顺序处理；每条原ID、完整连续摘录和必要来源语境保持不变。脚本发现的跨题重复/共享原文比较必须在同一批同时看到双方，不为凑批大小截断关联组。逐条保留真实审核运行，不将最后一批的认证盖到前面各批。正文完成取舍后，再仅用实际保留的完整判断审核标题。所有批次、局部修补及标题仍共用原阶段剩余预算，缺少任何一条审核不能伪称全文已核验。

境外范围字段使用两个字符串组成的JSON数组，片段ID逐字复制本条原文，不依原始行号猜编号。宿主可将完全明确的字符串化双ID数组无损转成数组，包括[o1/1, o1/2]这一编码；最终仍过原来同源、有序、存在的逐字切片门禁，并记录原字段和编码修复。跨原文、倒序、越界、多个值或无法无歧义解码的范围不修猜。

### 标题覆盖与跨议题唯一归属

标题复核的局部格式错误不得抹掉其他已完成的原生审核。仅当实际调用成功结束、唯一终态回答具有完整的heading_reviews数组边界时，宿主可保留其中逐条完整解析的JSON对象；不改字、不补ID、不推断审核结论。畸形对象及其可能冲突的ID隔离，缺少审核的标题单独使用中性展示并标为partial。完整日志、回答哈希和隔离位置保留；重复ID、未知ID、未闭合结构或未完成的流式回答不借此获得认证。每条保留审核仍须通过原有观点支持、完整组员覆盖、政策范围及真实运行归属检查；不额外调用模型，不改正文观点，不把局部恢复称为全文质量达标。

正文独立复核沿用同一完整原生行恢复机制：仅对成功终态中的完整reviews数组逐行解析，未知/重复ID、边界不完整或跨工作目录日志不恢复。正常行保留原生审核及原运行归属，坏行仅留下待补核ID，由现有局部字段重试核验对应冻结原文，最多45秒且不增加阶段预算。若补核仍失败，仅该行标为宿主未完成，不能把其他正常审核一起丢掉；恢复格式不是替模型判定支持、不支持或归题正确。

分簇标题必须获得该簇全部保留论断的支持；独立审核的 supporting_claim_ids 只覆盖部分成员时，宿主拒绝采纳该标题，而不是把其余成员硬放在第一人的判断下。不同机制不能仅凭宏观主题相同合并，也不以顿号拼接多个中心来冒充共同判断。一级议题标题须以原生布尔 scope_preserved 确认保留输入议题的完整政策对象；不能为了短标题只留下第一簇或一个子对象。没有可采用的概括时保留原议题名称，不补造结论。这些检查只约束展示标题，不改冻结原文、主体和论断。

同一声明主体、职务和原始URL的完全相同判断跨议题出现时，脚本标记全部证据ID，已有全局独立审核按实际政策对象确定最直接的归属。脚本不自行删观点、猜去向或合并同名不同职务的人。原文有不同实质判断可以分属不同议题；不能靠稍改措辞将同一判断重复收录。

### Early publication-metadata validation

Before moving to the next author topic, validate selected web articles against their literal original publisher and complete publication date. Explicit source/date metadata on one line, or a standalone full timestamp immediately followed by a source/publishing-location label, may establish a publication date. Navigation dates, narrative event dates, month/day without year, and conflicting metadata dates must not be inferred. A verified out-of-period header is a deterministic exclusion with original model selection preserved in audit.

Other invalid selected-web metadata gets at most one local model repair, capped at 45 seconds and the current stage's remaining allocation with future-topic reserve. It uses a separate hash-checked model cache, never overwrites the raw author answer, and must pass the same original-text metadata gate afterward. Missing dates cannot be supplemented from URLs or meeting years. This does not reset stage retries or enlarge the full-run budget.
# Cross-model scope and truthful empty sections

Every impact, comparison or forecast must preserve the original effect object, population, range and strength. A judgment about differences in property values is not a judgment about overall differences between regions; adding “may” does not repair an expanded object. Authors, selected-field repair and fresh independent review use the same maintained writing rule.

A comment's stated condition is not interchangeable with its parent post's policy action. The real parent may establish topic relevance, but cannot add an action→condition causal step or a wish that the commenter did not express. A heading must summarize the original comment's actual judgment and attitude. Frozen labels, quotations and sentiment denominators remain unchanged.

When no quote is ready, fixed prose distinguishes verified actual samples without suitable approved quotations, unverified candidate clues, and no captured samples. Do not write “no comments obtained” merely because formal approval is zero. This notice never creates a sentiment ratio or semantic approval. The final Word audit checks that eligible approved domestic quotations actually appear in the body section; appendix or JSON presence cannot mask a missing displayed quotation. Explicit user prose overrides are recorded as not applicable, not certified by this coverage check. Coverage is separate from semantic correctness and physical pagination.
