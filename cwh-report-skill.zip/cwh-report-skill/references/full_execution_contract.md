# CWH Report Skill

## Outcome and inputs

Turn one organized standard workbook or a raw monitoring-export bundle into a validated report package. Discover the meeting date from the original government communique, then have the model read its complete agenda. A meeting date is an optional confirmation/correction, not a required upload field. If the communique is missing or incomplete, accept an official public link; unresolved dates or multiple periods require confirmation.

Do not ask the user to prepare analysis JSON, comments, charts, or a third input file. Those are internal artifacts. Numerical传播口径 starts from the monitoring workbook; overseas news is reconciled from its complete reviewed records plus verified public supplements before final rendering. Qualitative claims come only from traceable reviewed evidence. Keep engineering status and missing-input details in audit files, never in formal prose.

The standard Excel is an output when raw exports are supplied, not an extra prerequisite. Learn general grouping formulas from paired examples, and audit raw versus embedded standard daily cells separately from those formulas. See `references/raw_workbook_pipeline.md`; never force raw numbers toward a historical benchmark.

Current approved writing contract is in `config/editorial_template.v1.json` and `references/word_fill_in_template.md`: one sourced meeting-news headline in the focus sentence; full official agenda labels in tables; source-backed attitude judgments in domestic headings; at most two formal uses of one source across different topics; at least two sources per numbered subpoint. Keep additional valid evidence in the workbench. These editorial limits do not authorize fabricated agreement, truncation or changing source stance.

## Default execution contract

In bounded profiles, deliver all available content even when a topic has no usable interpretation or comments. Controllers record real search/review coverage and explicit gaps, remove empty clusters, independently verify the claims that do exist, and continue Word/Excel/Markdown/HTML generation. Quantity/density targets must not withhold all outputs. `delivered_with_gaps` is a completed available-content delivery, not proof of absent discussion or certified full coverage. Source integrity, exact excerpts, numerical consistency and artifact existence remain enforced. Never fill gaps with fabricated voices, quotes or ratios.

The compiled bounded worker contains article-reading, grouping and independent-review interruptions locally. A timed-out or malformed article response remains unread. Grouping failure preserves extracted claims only in the workbench candidate reserve: never concatenate them into prose, never invent a source-order group, and never use an agenda label to disguise incomplete writing. Retry only the small selection/grouping task within its existing budget; unresolved material remains candidates with an explicit gap. Unfinished independent reviews cannot enter prose. Record every interruption and all remaining coverage gaps. Allocate remaining author time fairly across topics, preserving the global delivery reserve. This is available-content recovery, not evidence that a provider completed every semantic task. Authentication, permissions, corrupted source identities and missing input cannot be relabelled as successful research; the outer runner still emits the separate labelled review package when formal delivery is unavailable.

Use model-neutral `bounded_45m` by default. The complete job is limited to2700seconds, research cutoff2460seconds and global delivery buffer240seconds. Time starts at the first run and includes waits and retries; resume and invalidation never reset it. Keep40m/60m as explicit alternatives. See [references/adaptive_web_research.md](adaptive_web_research.md) for protected open-web research and targeted discovery for weak raw topics. These are budgets, not completion promises or evidence approval.

Before a full run, read [references/model_neutral_execution.md](model_neutral_execution.md) and [references/resumable_pipeline.md](resumable_pipeline.md). The machine-readable policy, generated task contract, and validators override narrative examples when they differ.

The controller resolves stage budgets from input mode at intake. For explicit `bounded_60m`, standard input gives workbook validation 30 seconds, domestic authoring 1290 seconds and independent review 600 seconds. Raw input gives workbook processing 780 seconds (including its protected 180-second generation reserve), domestic authoring 1080 seconds and independent review 600 seconds. The report body takes priority over appendix completion; unfinished appendix records stay explicitly pending, not approved or excluded. Both modes preserve rendering and final checks within the same 3600-second limit; see `references/model_neutral_execution.md`. Never change a running job's clocks to apply a new policy.

The word cloud is a required delivery image. In bounded delivery, the hotword count is a quality target, not a reason to withhold a cloud made from a shorter genuinely supported, second-pass-reviewed list. Never manufacture words to reach 36. If workbook-time hotword review is deferred, the later `hotwords` node must run recovery rather than mark the missing image as succeeded. Preserve completed material, shared deadlines and delivery reserves. A report without the cloud remains incomplete even when other available files are emitted. The explicit 40-minute raw-input profile reserves up to 480 seconds for normalization; the global 2400-second clock is unchanged. The integrated 40-minute profile gives domestic authoring 780 seconds, a 2160-second research cutoff and a 240-second delivery buffer; independent review, rendering and gate allocations remain unchanged. See `references/raw_sample_screen_integration.md` for public-web reading protection.

Bounded profiles carry forward unused completed predecessor allocations, including actual waits, within the original total. In45m mode raw screening cannot consume protected public-web discovery/read time; weak topics receive native-planned additional queries and weighted reading opportunities. Full sources, actual run receipts, exact unread IDs and independent verification remain required. See `references/adaptive_web_research.md`.

Run the preflight before expensive model work:


```powershell
python scripts/cwh_preflight.py --skill-root .
```

Run complete work only through the durable pipeline:

```powershell
python scripts/run_cwh_resumable_pipeline.py run `
  --job-dir outputs/cwh_pipeline_job `
  --agenda "会议日期或完整议程" `
  --system-workbook "D:\path\CWH舆情情况.xlsx" `
  --execution-profile bounded_45m
```

For a raw bundle, replace `--system-workbook` with `--raw-input-dir`; omit `--agenda` for automatic meeting identification. Resolve metadata according to [references/raw_workbook_pipeline.md](raw_workbook_pipeline.md). Direct stage scripts are for diagnosis and isolated tests, not an alternative orchestration path.

Establish each raw child workbook's topic identity before semantic research. Use explicit export titles, a traceable monitoring-task/event-ID mapping, or an explicitly user-confirmed convention that numbered child files follow the current communique's agenda order. Agenda order alone, filename sorting and similar quantities are not identity evidence. Preserve the user's confirmed convention instead of repeatedly asking, but never make it a universal default. Keep the actual basis in period metadata, preserve combined statistical groups, and do not request another analysis file from the user. If identity is genuinely unavailable, ask only for the missing correspondence and retain the unresolved state; never guess factual labels or use another period's displayed dashboard. A benchmark-assisted correction is separately labelled, not a production fallback.

For raw inputs without explicit metadata, the workbook node first uses `scripts/cwh_meeting_intake.py`: scan all original public-article rows for the current government communique, preserving complete bodies outside the TOP ranking; if absent use the supplied `--communique-url`. The shared model reads the full text to group the complete agenda, not a regex split of deployment verbs. `--confirm-agenda-order` records an actual user confirmation, not an automatic default. Check date, source hash, literal topic evidence, distinct child indices and complete topic coverage before labelling tables. A fetched page is `text_acquired`, not AI-read. The workbench exposes the fallback URL and the two statuses separately. Read [references/meeting_intake.md](meeting_intake.md) when using this entry.

For an unattended model host, read [references/model_worker_host.md](model_worker_host.md). The host runs scripts; models should not need shell permission. A full-report request must not use `--until-stage` as its final invocation. Paused/workbook-only results are not report completion. Without an automatic worker, complete the current JSON task and resume; do not repeatedly resume unchanged outputs.

New jobs automatically read an already-confirmed numbered-child convention from `cwh_project.json` in the launcher working directory; isolated launchers pass `--project-config` explicitly. Freeze its confirmation evidence and hash in the job contract. Never ship a user's confirmation as a universal Skill default, infer confirmation from raw documents, or ask again solely because the meeting changed. Missing or conflicting child identities still require resolution. See `references/meeting_intake.md` for the small configuration schema.

An incomplete full invocation generates `review_delivery/` separately from formal `report/`. Its Word and fixed-template workbench are labelled 待审核稿 and never pass the formal gate. Only hash-verified accepted workbook facts and independently verified viewpoints enter the review prose; missing evidence remains explicitly missing. This may be a partial/status-only draft, not a completed report. Diagnostic calls may use `--no-review-delivery`; this does not waive final delivery requirements.

For the integrated raw-article screening and supplied-comment route, read [references/raw_sample_screen_integration.md](raw_sample_screen_integration.md). Configure the actual screening model in the host before raw research; the script never silently switches models.

## Model boundary

Each AI stage receives one `tasks/<stage>.json` generated by `scripts/cwh_model_contract.py`. The worker may write final artifacts only to `declared_outputs`, and intermediate seeds, raw responses and batches only under its `stage_workspace`. It must not:

- modify Skill code, configuration, validators, templates, pipeline state, event history, hashes, or finished report files;
- invent URLs, source pages, timestamps, people, quotations, comments, identifiers, or successful status;
- run downstream stages or weaken a gate;
- pad text to pass a length check.

Models decide only semantic relevance, candidate disposition, speaker identity, atomic claims, stance, cluster assignment, comment quality, sentiment, translation, and semantic support. Scripts own stage order, workbook calculations, query-plan generation, identifiers, deterministic prose assembly, validation, hashing, retries, rendering, and delivery status.

Missing evidence is a structured blocker. A model assertion that work is complete has no effect; only validators advance state. `waiting_ai`, `waiting_login`, and `waiting_review` are resumable conditions, not success. A failed stage is rearmed on the next explicit `run`; never hand-edit attempts or hashes.

### Single-worker, low-token operation

- Default to one active model worker and serial stages; do not spawn agents unless the user explicitly requests them. Independent second-pass review remains a separate sequential run with fresh context, not simultaneous agents or author self-certification.
- Read this entry and the execution contract once per run, then only the current task's required references and inputs. Reuse existing accepted artifacts and source snapshots; do not repeatedly dump all files, search the same URL or redraft complete report sections.
- Return the current stage's structured fields, not a narrative status essay. Use existing batching scripts; repair only reported invalid fields while preserving accepted source text and identifiers.
- In compiled large-topic authoring, article batches only read full sources and extract attributed claims with exact ranges. They do not draft provisional headings or groups. A separate native synthesis selects and groups existing claims, using explicit priority and scripted reserve bookkeeping in bounded mode. Extraction success does not replace synthesis or independent verification.
- For a large monitoring corpus, use the controller's per-topic reading indexes rather than repeatedly loading the whole JSON. Bounded mode targets at least `min(12, topic corpus size)` actual full-article reviews per topic; available-with-gaps delivery may fall short only with a complete hash-matching corpus index, the exact unread ID set and a reading-shortfall notice. Unread rows are never counted as reviewed. Exhaustive mode still requires all rows. Full source support and independent claim review are unchanged.
- New bounded plans freeze a time-aware initial reading allocation, starting at 12 monitoring articles plus profile-specific public-page opportunities (six in40m, four in60m;45m uses6/10/12 according to current raw nomination gaps) per topic when time is tight and expanding toward configured ceilings when time permits. An optional native metadata-priority call selects which observed pages to read, never certifies their content. Failed optional ranking falls back to recorded discovery order; permission or quota failures remain real blockers. Limits do not truncate source text or waive independent verification.
- Large raw hotword packets in available-with-gaps delivery are reviewed in native batches of at most 40 candidates and a separate native global second pass. Preserve all original candidates, topic indices and per-term source windows. Native source-backed phrase additions remain allowed; the original full-source gate recalculates evidence counts. Empty or unreviewed results do not become completed hotword reviews.
- If the global review retains fewer than the configured minimum (normally 36), use the remaining stage budget for one additional model nomination from the retained original text, followed by a separate combined-list review. Ask for uncovered policy tools, concrete concerns, mechanisms and affected groups, not synonymous variants of existing words. Scripts verify literal support and recalculate frequencies; repeated drawing instances never count as additional unique terms. A failed optional supplement preserves the previously reviewed list and records the remaining shortfall; it must not erase the cloud or reset the shared deadline.
- For raw-monitoring candidates, supply the real `raw_evidence_record_id`. The controller fills missing original source fields/full text from that immutable row; do not copy long snapshots or calculate hashes manually. Existing wrong values still fail validation.
- The controller completes missing deterministic IDs, SHA-256 values and unique exact excerpt offsets before draft validation. Ambiguous matches remain errors; query/candidate references must still be consistent. Never manufacture IDs for absent evidence.
- Do not manually calculate hashes, prose punctuation or numbering. Use `scripts/cwh_timing_report.py --job-dir <job>` to inspect recorded stage/command timings; it does not measure token usage or certify success.
- CLI output defaults to a compact handoff: current status, task, errors and stage status map. Full history remains in `pipeline_state.json`; use `--output-format full` only for diagnosis or a legacy stdout consumer.

## Input Routing and Stage Boundaries

Raw heat exports currently require `细分渠道-日趋势`. Use the mapped detailed news column for domestic mainstream media; classify 百家号 and 头条 as new media, preserving separate source fields. Do not fall back to ordinary `日趋势` or shift counts into APP to match a historical report. See `references/raw_workbook_pipeline.md`. The current `config/report_presentation_policy.v1.json` keeps formal sentiment percentages blank across Word, HTML and Excel, while preserving actual comments and sample labels.

The pipeline order is fixed:

1. `preflight`
2. `intake`
3. `workbook`
4. `research_plan`
5. `domestic_viewpoints`
6. `domestic_evidence_verification`
7. `domestic_comments_sentiment`
8. `overseas_evidence`
9. `hotwords`
10. `domestic_remaining_research` (new45m jobs only; reuse completed readings, supplement, independently review; preserve verified fallback)
11. `render`
12. `delivery_gate`

If the workbook already contains `关键词`、`总事件`、`子事件1...N` and `子事件数据汇总`, treat it as the standard workbook. Otherwise run the independently testable raw-workbook stage first. When the user asks only for workbook organization or comparison, stop after `workbook` (stage 3).

## Non-bypassable evidence rules

- Workbook topics, dates, event IDs, exclusions, totals, channel counts, trend data, and embedded charts are authoritative. Do not infer or rewrite them.
- Read `config/source_registry.v1.json` as a priority seed, not an allowlist. Follow the grouped lanes and caps emitted by `research_plan.json` in both bounded profiles; only `exhaustive` expands every required source separately.
- Preserve an explicit `eligible`, `duplicate`, or `excluded` decision for every reviewed search result, with the executed query and URL snapshot.
- Each eligible claim needs a verified in-window publication time, immutable full-text snapshot and hash, one speaking subject, a continuous excerpt with exact offsets, and a substantive `formal_claim` (normally 50-120 characters, preferably 80-100, maximum 150; punctuation included, attribution and whitespace excluded). Edit overlong claims against the original before freezing and independently review them; never truncate frozen text. Unresolved claims remain complete audited reserves. Multiple domestic body paragraphs within a topic require consecutive 一是/二是 labels, at least two distinct sources per group, and all of that group's samples in one paragraph. A sole group may be one unnumbered paragraph. Extract distinct judgments separately even from one speaker; one judgment may use several short sentences. Search snippets are not source snapshots.
- Interpretation eligibility is separate from exact quotation and source support. Pure retelling of meeting requirements or existing policy provisions remains facts, not the publisher's own judgment. Use the configured `viewpoint.interpretation_eligibility_rule`: identify the real subject's independent judgment about the current decision, preserve implementation stages and conditions, and never add an evaluation just to turn a fact into an interpretation.
- In bounded mode, normally select 4-6 attributed excerpts across 2-3 judgments per topic; excerpt count is not distinct-subject count. These are editorial references, not quotas or hard deletion limits. Add material only for indispensable information gain; keep other valid candidates as `formal_use=reserve`. The existing 12-subject safety cap and traceable thin-evidence exceptions remain, never pad to meet them. Do not shrink discovery or full-text reading. Exhaustive mode maps every eligible voice into prose.
- The authoring model does not certify its own claim. A separate model run with a different run ID reviews every proposition against the frozen source bundle.
- After independent retention, a numbered group may lose a source. Within the existing review budget, `cwh_verified_grouping.py` may ask the model to regroup only the retained claim IDs. Scripts preserve every claim, identity, source and existing review exactly; no deletion, rewriting or guessed grouping. New group headings still require their independent review. This is a local structural edit, not a new source certificate.
- Before independent review, `scripts/complete_cwh_evidence_structure.py` completes mechanical draft fields and `scripts/normalize_cwh_analysis.py` regenerates `cluster.details` from ordered atomic claims. Do not preserve model-written paragraph wording or run completion on a frozen verified bundle.
- Draft and final density checks share `scripts/cwh_viewpoint_gate.py`: normally two independent speakers and 120 Chinese characters. A thinner cluster needs `thin_cluster_exception` with non-empty `reason`, `search_evidence`, and `reviewed_by`; accepted exceptions remain in the final audit. This never waives source mapping, per-claim quality or independent semantic review. Repeating a speaker or attribution verb does not create another voice.
- Domestic comments must be real in-window comment/reply text with platform, original URL, comment identifier, and formal-use review. Article bodies, search snippets, and comment counts are not comments.
- Validate raw comment provenance first. Then remove emoji, including embedded emoji and recognized platform reaction tokens, from a working copy before model reading and all display/quotation handoffs. Retain immutable raw text and IDs; exclude empty cleaned rows. Never delete substantive words or rewrite the remaining opinion.
- Pass the reviewed current communique into comment review for policy-object disambiguation. A topic label is a proposed assignment, not proof: the independent quote reviewer can reject a wrong or uncertain assignment, with original classification and actual reviewer retained. Mere display-format rejection does not change sentiment membership. Short concrete suggestions need no essay-length explanation and need not repeat measures already in the communique.
- Sentiment ratios come only from the reviewed comment-level sentiment pipeline. Hide formal sentiment when a topic is not `ready` or has a zero denominator.
- Overseas media and overseas public comments are separate evidence universes. Review meeting relevance, category, deduplication, and Simplified Chinese translation before formal use. A completed zero-result collection is not the same as a failed collection.
- Preserve monitoring-system images as source artifacts. Report trend/topic charts must instead use the baseline-locked templates in `config/report_visual_style.v1.json` and `scripts/cwh_report_visuals.py`; only current date, full topic labels and counts vary. The nine-column/two-header-row topic table uses `templates/topic_table.xml`, including blank sentiment cells when no reviewed ratio is available. Word and workbench use identical generated chart bytes. Public evidence does not change workbook counts except through the audited in-window overseas-media reconciliation stage.

Read [references/analysis_bundle_schema.md](analysis_bundle_schema.md) when producing or repairing the analysis bundle. Read [references/sentiment_pipeline.md](sentiment_pipeline.md) for comment collection and sentiment. Read [references/system_data_contract.md](system_data_contract.md) when adapting workbook fields.

## Formal writing and output

For domestic media/self-media viewpoints, apply the configured `speaker_eligibility_rule` and `attribution_body_rule`: named professionals need source-verified institution, role and name; ordinary or anonymous people and self-reported experience do not qualify for this section. Attribute account-authored analysis to the full account name and expert quotations to the expert. Formal claims omit interview-process wording and repeated speaker/account headers. Preserve original source text and keep genuine netizen comments under the separate comment rules.

Use the shipped `templates/cwh_fill_in_template.docx` for Word output; read [references/word_fill_in_template.md](word_fill_in_template.md) when developing or repairing template filling. The renderer fills 11 named slots and retains fixed headings. Do not ask a model to recreate Word layout or invent a replacement template. Scripts own fonts, tables, charts, paragraph boundaries and placeholder checks; models own evidence selection and semantic grouping. Physical paragraph splitting never certifies source-order recovery as completed editorial grouping.

Read [references/formal_report_rules.md](formal_report_rules.md) before rendering. General evidence/writing rules are in `config/formal_writing_rules.v1.json`. The user-approved fixed wording and configurable chair default are in `config/editorial_template.v1.json`; `cwh_writing_rules.writing_rules()` merges them for every model and renderer. Do not ask models to rewrite fixed prose. Editorial defaults are not measurements or source certifications. Current sourced meeting metadata takes precedence; dates, agendas, topics, figures and quotations must come from the current run. The shipped Word is the reviewed fill-in skeleton, not a model-authored layout.

The formal report uses the fixed chapters `一、舆情传播情况`、`二、境内舆论情况`、`三、境外舆论情况` and `附录`. Lead with data, then interpretation. Use evidence-supported stance headings and concrete attribution. Do not write vague aggregations such as `媒体普遍认为`, source lists, engineering notes, or placeholder prose.

Use the shared claim-composition and cluster-structure rules in the current author task: concrete judgment plus its actual reasoning or conditions, not article introductions. Cluster count follows substantive evidence (usually 2-3, up to 5-6 distinct judgments when supported), never a mandatory topic checklist. Baseline style is useful; its dates, sentiment ratios, people, slogans and unsupported attention claims are not current facts.

Scripts share one rule configuration for Word and Markdown: opening, chapter names, propagation sentences, source ordering, attribution, numbering, comment lead, hotword frames and overseas transitions. Topic counts and numbering are dynamic; never discard the ninth group or shorten a qualification to fit a template. Source-backed `meeting.chair_name` and `meeting.chair_source` override the configurable approved chair default; use the neutral opening only when neither is available. Keep explicitly approved fixed editorial phrases in `config/editorial_template.v1.json`; do not infer additional names, publishers, peak dates, placement or factual-report majorities from historical examples. Editorial wording never certifies those claims as measured findings.

Raw overseas reviews and supplemental research use the same configured analysis-summary rule. Formal summaries state actual judgments and source-supported reasoning, not article introductions, stock-movement roundups or audit explanations. Keep review reasons separate and retain all qualifications; renderers must not truncate a reviewed summary at an arbitrary length.

The workbench is also script-owned: `scripts/generate_dashboard.py` injects structured data into the shipped `assets/cwh_dashboard_template.html`. Layout, styles, charts, navigation, evidence cards and export controls are reusable assets, not model coding tasks. The `render` stage produces Word, Excel, Markdown and HTML together; never ask a model to rebuild the page, emit HTML/CSS/JavaScript, redraw existing system charts or duplicate data into a separate hand-authored dashboard. Do not read the large HTML template into the model context during a normal report run. Template defects are Skill-development issues, not permission for a report worker to patch the renderer.

Required final artifacts are synchronized Word, report Excel, `report_data.json`, `cwh_audit.json`, evidence-mapping audit, and self-contained HTML. `delivery_gate` must verify all declared artifacts and hashes, including the same `evidence_id` mappings in structured data, Word, and HTML. A partial artifact set is not formal completion.

## Focused references


For user-facing delivery, run `scripts/publish_cwh_artifacts.py --report-dir <report> --output-dir <delivery> --model <actual model label>`. Keep canonical pipeline files and their hashes. The publisher creates byte-identical names beginning with the model and the actual generation HHMM timestamp, not the time they were copied. It never overwrites an older labelled version.

- [references/cwh_requirements.md](cwh_requirements.md): business acceptance criteria.
- [references/report_schema.md](report_schema.md): structured report fields.
- [references/capability_matrix.md](capability_matrix.md): runtime capability and fallback boundaries.
- [references/raw_workbook_pipeline.md](raw_workbook_pipeline.md): raw exports to reviewed standard workbook.
- [references/formal_report_rules.md](formal_report_rules.md): layout, wording, appendices, and rendering details.

Run the regression suite after changing policy, validators, or rendering:

```powershell
python -m pytest -q
```

### Bounded hotword replenishment

The integrated hotword worker uses the exact excerpts behind independently verified selected viewpoints and formally selected comments, not the whole raw monitoring corpus. Counts are recomputed over those source articles' full snapshots and selected comments. After the first independent term review, fewer than36 retained terms triggers at most one additional extraction and independent review if at least60seconds remain before the existing hotword-stage deadline. Send retained and rejected terms with reasons; forbid recycled terms and synonym padding. Search no new pages for this action. Only independently approved additions can be merged and rescored; no time, failure or absent additions preserves the first verified list. Final output may remain below36 with a recorded gap. This never resets the45minute job clock or the stage allocation.

### Automatic remaining-time research (45m)

New45m jobs automatically run a supplemental node after primary research, comments, overseas and hotwords. It completes only the unread subset of the original screening queue, retries incomplete web readings, and targets topics with few verified voices. Completed article extractions are cached per immutable source/context/model/rules, independently of batch membership or scoped IDs; changed source, topic or rules is a different task. Native log hashes and payload checksums must match. Completed topic selection and source/search checkpoints are also reused. Cache hits are not new readings or independent approvals.

The initial50raw articles are the first queue, not the corpus limit. After independent review, weak topics recall a small batch from the recorded unread reserves, ranking local policy argument hints with only a small length penalty. One multi-topic full reading supplies all agenda items; completed originals and exact whole-text copies are not resubmitted. Existing unselected nomination backlogs go to selection before new raw readings. Raw recall has its own immutable input/results receipt and retains the original45mclock and a protected feedback-search opportunity.

Additional query planning receives the actual prior article rejection reasons and a separate unread list. It must change direction after old-law, wrong-policy, primary-communique or marketing noise, without inferring unannounced legal details. Formatting variants of executed queries are not new searches. Explicit, unambiguous publication dates outside the monitoring period are resolved before model dispatch and labelled metadata-only, never as completed semantic readings.

The original global clock stays fixed. No native reading starts with less than60seconds of its protected opportunity. Reserve180seconds for native synthesis and240seconds for independent review before the existing research cutoff, then retain the global delivery buffer. Additional sources and unreviewed candidates remain in the supplemental workspace; a failed draft or review cannot replace the verified primary bundle. Render and final mapping gates consume the hash-verified effective bundle selected by `remaining_research_receipt.json`. The whole test host includes launch, retries, output checks and file labelling in its45minute clock and has no extra30second grace period.
