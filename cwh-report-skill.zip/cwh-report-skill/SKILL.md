---
name: cwh-report-skill
description: 从屿海监测原始数据包或标准总表生成国务院常务会舆情报告，支持国内模型全文分析、公开检索、独立复核与 Word、Excel、工作台交付。
---

# 常务会舆情报告

用户给出一期 ZIP、原始表文件夹或标准总表，要求生成常务会报告时，直接运行本包。用中文回复。本机需有已登录的 WorkBuddy、Python 3.11 以上、Node.js 和 Excel 逐表渲染组件。首次在新电脑使用，先运行下方环境检查。已有模型宿主的接法见 [模型运行说明](references/model_worker_host.md)。

## 带教使用

在 WorkBuddy 中发本技能的下载链接或 ZIP，告诉它“请安装这个技能，先检查我这台电脑能不能运行”。安装按 [本机准备](references/local_setup.md) 执行。之后给它一期屿海数据并说“用这个技能生成本期常务会舆情报告，完成后给我 Word、Excel 和工作台，告诉我哪里还需要我核对”。默认使用标准版 GLM。用户点名其他模型时按实际型号运行。

## 助手执行

1. 找到本技能的实际位置与可用的 Python 解释器。首次运行 `python scripts/run_with_workbuddy.py --check`，缺少依赖按 [本机准备](references/local_setup.md) 处理。此检查只验证本机环境，登录和模型权限以真实调用为准。
2. 在技能外指定本期独立任务目录。使用绝对路径运行 `python scripts/run_with_workbuddy.py --input "本期文件或文件夹" --job-dir "本期任务目录"`。可用 `--model` 指定 `glm-5.3-ioa`、`deepseek-v4.1-flash` 或 `hy4-preview-ioa`。机器自动从原始文章识别会议。缺完整通稿时才请用户补链接，调用时传 `--communique-url`。编号子表优先使用本项目已确认的 `--project-config`，只有编号顺序确实不明时再问。基准报告仅供事后对照。
3. 运行期间读取任务目录下的 `pipeline_state.json` 跟进。单次运行总预算 45 分钟。对同一配置续跑使用同一目录。若需修正通稿或映射，先向业务说明再以新目录运行。各期、各模型使用独立目录。
4. 查看 `artifacts/delivery_gate.json` 和实际生成文件。通过交付检查后给出 `report/` 下 Word、Excel、工作台的绝对路径。存在缺口时告诉使用者哪些议题缺样本或哪些来源没读完。若流程只生成 `review_delivery/`，说明停在哪一步，只交付标记为待审核的现有文件。

## 业务口径

程序计算传播统计，模型从屿海和公开网页提取有原文依据的观点，再用独立上下文复核。关联到同一份来源的已读材料复用。薄弱议题用剩余研究时间定向补充。境外公开补搜只在时间、来源及报道范围核实后参与去重回算。写报告时保留姓名职务或账号全称，同一主体同一议题通常采用一次。参见 [执行细则](references/full_execution_contract.md)、[写作模板](references/word_fill_in_template.md) 和 [可恢复管线](references/resumable_pipeline.md)。采集权限、样本缺失、未完成阅读或未审核观点须如实记录。

## Input Routing and Stage Boundaries

WorkBuddy 启动脚本调用 `scripts/run_cwh_resumable_pipeline.py`。仅要求整理或核对 Excel 时，加上 `--workbook-only` 并在工作簿节点结束（stop after `workbook`）。输出位置是任务目录下的 `artifacts/CWH舆情情况_标准总表.xlsx`。已整理的标准总表直接作为输入。详细口径见 [原始表处理](references/raw_workbook_pipeline.md)。
