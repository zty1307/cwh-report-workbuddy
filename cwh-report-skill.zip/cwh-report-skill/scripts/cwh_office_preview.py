"""Optional whole-sheet previews using the local LibreOffice Calc installation."""
from pathlib import Path
import json
import os
import re
import shutil
import subprocess
import tempfile
import sys
from contextlib import ExitStack


def windows_excel():
    if os.name != "nt":
        return False
    import winreg
    try:
        return bool(winreg.QueryValue(winreg.HKEY_CLASSES_ROOT, r"Excel.Application\CLSID"))
    except OSError:
        return False


def soffice_path():
    override = os.environ.get("CWH_SOFFICE")
    if override:
        return Path(override) if Path(override).is_file() else None
    options = [shutil.which("soffice"), shutil.which("libreoffice"),
               "/Applications/LibreOffice.app/Contents/MacOS/soffice",
               Path.home() / "Applications/LibreOffice.app/Contents/MacOS/soffice",
               Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "LibreOffice/program/soffice.exe"]
    return next((Path(p) for p in options if p and Path(p).is_file()), None)


def render_sheets(workbook, sheet_names, previews):
    import pypdfium2 as pdfium
    from openpyxl import load_workbook
    actual = load_workbook(workbook, read_only=True)
    try:
        if actual.sheetnames != sheet_names:
            raise ValueError("Excel 页签顺序与待渲染清单不一致")
    finally:
        actual.close()
    with tempfile.TemporaryDirectory(dir=previews) as temp:
        folder = Path(temp)
        options = json.dumps({"SinglePageSheets":{"type":"boolean","value":"true"}}, separators=(",",":"))
        soffice = soffice_path()
        if soffice:
            cmd = [str(soffice), "-env:UserInstallation="+(folder/"profile").resolve().as_uri(),
                   "--headless", "--norestore", "--convert-to", "pdf:calc_pdf_Export:"+options,
                   "--outdir", str(folder), str(workbook.resolve())]
        elif windows_excel():
            cmd = [sys.executable,str(Path(__file__).with_name("export_sheet_pdfs.py")),
                   str(workbook.resolve()),str(folder)]
        else:
            raise ValueError("未找到可以逐表渲染的本机办公软件。")
        subprocess.run(cmd, check=True, timeout=90, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        with ExitStack() as stack:
            pages = []
            pdfs = [folder/(workbook.stem+".pdf")] if soffice else [folder/f"{i+1}.pdf" for i in range(len(sheet_names))]
            for pdf in pdfs:
                doc = pdfium.PdfDocument(pdf)
                stack.callback(doc.close)
                if not soffice and len(doc) != 1:
                    raise ValueError("Excel 单表导出的页数异常")
                pages.extend((doc, i) for i in range(len(doc)))
            if len(pages) != len(sheet_names):
                raise ValueError("LibreOffice 导出的页数与工作表数不一致")
            for name, (doc, i) in zip(sheet_names, pages):
                page = doc[i]
                width, height = page.get_size()
                scale = min(2, 3200/max(width,height))
                bitmap = page.render(scale=scale)
                image = bitmap.to_pil()
                try:
                    if image.convert("L").getextrema()[0] >= 250:
                        raise ValueError(f"工作表预览为空白：{name}")
                    filename = re.sub(r'[\\/:*?"<>|]', "_", name)+".png"
                    image.save(previews / filename)
                finally:
                    image.close()
                    bitmap.close()
                    page.close()
    return list(sheet_names), []
