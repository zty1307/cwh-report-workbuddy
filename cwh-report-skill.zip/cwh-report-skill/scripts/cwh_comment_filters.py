"""Deterministic comment cleanup; retain immutable raw sources for provenance."""
import copy
import re
from cwh_writing_rules import writing_rules


REACTION_TOKEN_RE = re.compile(
    r'[\[【](?:赞|点赞|鼓掌|玫瑰|心|爱心|比心|福|点亮平安灯|呲牙|微笑|大笑|笑哭|捂脸|偷笑|调皮|可爱|加油|奋斗|握手|抱拳|祈祷|祈福|合十|狗头|强|支持|庆祝|烟花|礼花|蜡烛|胜利|OK|允悲|流泪|大哭|泪|汗|衰|怒|愤怒|吃惊|惊讶|害羞|亲亲|嘻嘻|哈哈|挤眼|坏笑|嘘|可怜|抓狂|吐|晕|困|睡|疑问|思考|白眼|鄙视|憨笑|得意|再见|委屈|撇嘴|色|发呆|闭嘴|衰|酷|骷髅|太阳|月亮|蛋糕|礼物|红包|笑脸|耶)[\]】]', re.IGNORECASE)
EMOJI_RE = re.compile(
    r'[#*0-9]\ufe0f?\u20e3|['
    '\U0001F000-\U0001FAFF\U000E0020-\U000E007F'
    '\u2600-\u27BF\u2300-\u23FF\u2B05-\u2B07\u2B1B\u2B1C\u2B50\u2B55'
    '\u200D\uFE0E\uFE0F\u20E3]+')


def remove_comment_emoji(text):
    """Remove emoji sequences and known platform reaction tokens, not words."""
    return EMOJI_RE.sub('', REACTION_TOKEN_RE.sub('', str(text or ''))).strip()


def prepare_comment_review_capture(capture):
    """Normalize a copy after raw-source validation; stable source IDs stay fixed."""
    prepared = copy.deepcopy(capture)
    kept, changes = [], []
    for row in prepared.get('rows') or []:
        original = row['text']
        cleaned = remove_comment_emoji(original)
        if cleaned != original:
            row.update(raw_text=original, text=cleaned, text_normalization='remove_emoji_v1')
            changes.append({'sample_id': row['sample_id'], 'raw_text': original, 'text': cleaned})
        if not re.search(r'[A-Za-z0-9\u4e00-\u9fff]', cleaned):
            prepared.setdefault('excluded', []).append({**row, 'exclusion_reason': 'emoji_only_or_empty'})
        else:
            kept.append(row)
    prepared['rows'] = kept
    return prepared, changes


def is_procedural_only(text):
    value = re.sub(r'[\s。！!…]+$', '', str(text or '').strip())
    return value in writing_rules()['comments'].get('procedural_only_texts', [])
