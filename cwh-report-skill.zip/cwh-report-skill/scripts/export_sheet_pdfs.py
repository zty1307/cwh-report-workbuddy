"""Export one read-only workbook through an isolated Excel application."""
import sys
from pathlib import Path


def export(workbook, output):
    from comtypes.client import CreateObject
    excel = CreateObject("Excel.Application", dynamic=True)
    book = None
    try:
        excel.Visible = False
        excel.DisplayAlerts = False
        excel.EnableEvents = False
        excel.AutomationSecurity = 3
        book = excel.Workbooks.Open(str(workbook.resolve()), 0, True)
        for number in range(1, book.Worksheets.Count + 1):
            sheet = book.Worksheets.Item(number)
            sheet.PageSetup.Zoom = False
            sheet.PageSetup.FitToPagesWide = 1
            sheet.PageSetup.FitToPagesTall = 1
            sheet.ExportAsFixedFormat(0, str((output / f"{number}.pdf").resolve()))
    finally:
        try:
            if book is not None:
                book.Close(False)
        finally:
            excel.Quit()


if __name__ == "__main__":
    export(Path(sys.argv[1]), Path(sys.argv[2]))
