"""Narrow, audited JSON framing repairs; never invent values or source text."""
import copy
import json
import hashlib
import re


def unique_members(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON object key')
        result[key] = value
    return result


def remove_single_stray_period_before_string_value(text):
    """Remove exactly one decoder-confirmed dot outside an intact string value.

    No key, quoted value, numeric token or missing field is inferred. The whole
    object must then parse without any second repair or duplicate keys.
    """
    def reject_constant(value):
        raise ValueError('Non-standard JSON constant')
    try:
        json.loads(text, object_pairs_hook=unique_members, parse_constant=reject_constant)
        return None
    except json.JSONDecodeError as error:
        if error.msg != 'Expecting value':
            return None
        position = error.pos
    except ValueError:
        return None
    if text[position:position + 2] != '."':
        return None
    try:
        value, _ = json.JSONDecoder().raw_decode(text[position + 1:])
        if not isinstance(value, str):
            return None
        result = json.loads(text[:position] + text[position + 1:],
                            object_pairs_hook=unique_members, parse_constant=reject_constant)
    except ValueError:
        return None
    if not isinstance(result, dict):
        return None
    repairs = result.get('transport_repairs')
    if repairs is not None and not isinstance(repairs, list):
        return None
    result.setdefault('transport_repairs', []).append({
        'kind': 'removed_single_stray_period_before_string_value', 'position': position,
        'original_text_sha256': hashlib.sha256(text.encode()).hexdigest()})
    return result


def normalize_single_smart_quoted_member_key(text):
    """Fix one decoder-confirmed smart-quoted ASCII member key, not values.

    An intact simple key and colon must follow the decoder's error position.
    The whole object must parse after replacing just its two delimiters.
    Multiple defects, duplicates, escapes and incomplete output stay invalid.
    """
    try:
        json.loads(text, object_pairs_hook=unique_members)
        return None
    except json.JSONDecodeError as error:
        if error.msg != 'Expecting property name enclosed in double quotes':
            return None
        position = error.pos
    except ValueError:
        return None
    match = re.match(r'“([A-Za-z_][A-Za-z0-9_]*)”\s*:', text[position:])
    if not match:
        return None
    closing = position + len(match.group(1)) + 1
    repaired = text[:position] + '"' + text[position+1:closing] + '"' + text[closing+1:]
    try:
        result = json.loads(repaired, object_pairs_hook=unique_members)
    except ValueError:
        return None
    if not isinstance(result, dict):
        return None
    repairs = result.get('transport_repairs')
    if repairs is not None and not isinstance(repairs, list):
        return None
    result.setdefault('transport_repairs', []).append({
        'kind': 'normalized_single_smart_quoted_member_key',
        'positions': [position, closing],
        'original_text_sha256': hashlib.sha256(text.encode()).hexdigest()})
    return result


def insert_single_missing_member_comma(text):
    """Only a decoder-confirmed missing comma before an intact object key.

    No values, keys, containers or string content are supplied or changed.
    The entire result must parse after exactly one insertion; duplicate keys,
    multiple defects and incomplete strings remain failures.
    """
    try:
        json.loads(text, object_pairs_hook=unique_members)
        return None  # Valid JSON is not a repair request.
    except json.JSONDecodeError as error:
        if error.msg != "Expecting ',' delimiter":
            return None
        position = error.pos
    except ValueError:
        return None
    try:
        key, length = json.JSONDecoder().raw_decode(text[position:])
        if not isinstance(key, str) or not text[position+length:].lstrip().startswith(':'):
            return None
        result = json.loads(text[:position] + ',' + text[position:], object_pairs_hook=unique_members)
    except ValueError:
        return None
    if not isinstance(result, dict):
        return None
    repairs = result.get('transport_repairs')
    if repairs is not None and not isinstance(repairs, list):
        return None
    result.setdefault('transport_repairs', []).append({
        'kind': 'inserted_single_missing_member_comma', 'position': position,
        'original_text_sha256': hashlib.sha256(text.encode()).hexdigest()})
    return result


def escape_cjk_internal_quotes(text):
    """Escape CJK internal quotes, including one at the start of a value.

    Never repair keys, missing separators or truncated strings. Decoded text
    retains the original quote characters; downstream source gates still run.
    """
    output, stack, positions = [], [], []
    quoted = escaped = is_key = False
    string_start = -1
    previous = ''
    numeric_quote_positions = set()
    for match in re.finditer(r'(?<=[\u4e00-\u9fff])"[0-9]+"(?=[\u4e00-\u9fff])', text):
        numeric_quote_positions.update((match.start(), match.end() - 1))
    def cjk(character):
        return '\u4e00' <= character <= '\u9fff'
    def cjk_label(tail):
        return bool(tail) and (cjk(tail[0]) or (len(tail) > 1 and tail[0].isascii()
                                              and tail[0].isalnum() and cjk(tail[1])))
    for i, character in enumerate(text):
        if quoted:
            if escaped:
                escaped = False
            elif character == '\\':
                escaped = True
            elif character == '"':
                tail = text[i+1:].lstrip()
                following = tail[:1]
                closing = following == ':' if is_key else following in (',', '}', ']', '')
                if closing:
                    quoted = False
                elif (not is_key and i > 0 and i+1 < len(text)
                      and ((cjk(text[i-1]) or i == string_start + 1) and cjk(text[i+1])
                           or i in numeric_quote_positions
                           or (cjk(text[i-1]) and text[i+1] in '，。；：、！？）')
                           or (text[i-1] in '，。；：、！？（' and cjk(text[i+1]))
                           or (cjk(text[i-1]) and text[i+1] == '"' and cjk_label(text[i+2:]))
                           or (text[i-1] == '"' and i-1 in positions and cjk_label(text[i+1:])))):
                    output.append('\\')
                    positions.append(i)
                else:
                    return None
        elif character == '"':
            quoted = True
            string_start = i
            is_key = bool(stack and stack[-1] == '{' and previous != ':')
        elif character in '[{':
            stack.append(character)
        elif character in ']}':
            if not stack or (stack.pop(), character) not in (('[', ']'), ('{', '}')):
                return None
        output.append(character)
        if not quoted and not character.isspace():
            previous = character
    if not positions or quoted or stack:
        return None
    try:
        def reject_constant(value):
            raise ValueError('Non-standard JSON constant')
        result = json.loads(''.join(output), object_pairs_hook=unique_members, parse_constant=reject_constant)
    except ValueError:
        return None
    if not isinstance(result, dict):
        return None
    if 'transport_repairs' in result and not isinstance(result['transport_repairs'], list):
        return None
    result.setdefault('transport_repairs', []).append({'kind': 'escaped_cjk_internal_quotes', 'positions': positions,
        'original_text_sha256': hashlib.sha256(text.encode()).hexdigest()})
    return result


def single_fenced_json(text):
    """Decode one intact JSON object in a fence, allowing only a missing end fence.

    An absent Markdown delimiter is not an absent JSON delimiter: the whole
    remaining payload must parse strictly, without inventing any JSON content.
    """
    stripped = text.strip()
    match = re.fullmatch(r'```(?:json)?[ \t]*\r?\n(.*?)\r?\n```[ \t]*(?:\r?\n(.*))?',
                         stripped, re.DOTALL | re.IGNORECASE)
    kind = 'decoded_single_complete_json_fence'
    if match and stripped.count('```') == 2:
        payload = match.group(1)
        outside = match.group(2) or ''
    else:
        opening = re.fullmatch(r'```(?:json)?[ \t]*\r?\n(.*)', stripped,
                               re.DOTALL | re.IGNORECASE)
        if not opening or stripped.count('```') != 1:
            return None
        payload, outside = opening.group(1), ''
        kind = 'decoded_complete_json_without_closing_markdown_fence'
    if any(char in outside for char in '{}[]`'):
        return None
    try:
        def reject_constant(value):
            raise ValueError('Non-standard JSON constant')
        result = json.loads(payload, object_pairs_hook=unique_members,
                            parse_constant=reject_constant)
    except ValueError:
        return None
    if not isinstance(result, dict):
        return None
    repairs = result.get('transport_repairs')
    if repairs is not None and not isinstance(repairs, list):
        return None
    result.setdefault('transport_repairs', []).append({
        'kind': kind,
        'original_text_sha256': hashlib.sha256(text.encode()).hexdigest()})
    return result


def single_initial_json(text):
    stripped = text.strip()
    if not stripped.startswith('{'):
        return None
    def reject_constant(value):
        raise ValueError('Non-standard JSON constant')
    try:
        value, end = json.JSONDecoder(object_pairs_hook=unique_members, parse_constant=reject_constant).raw_decode(stripped)
    except ValueError:
        return None
    outside = stripped[end:].strip()
    if not outside or any(c in outside for c in '{}[]`') or not isinstance(value, dict):
        return None
    repairs = value.get('transport_repairs')
    if repairs is not None and not isinstance(repairs, list):
        return None
    value.setdefault('transport_repairs', []).append({
        'kind': 'decoded_single_initial_complete_json_with_plain_explanation',
        'original_text_sha256': hashlib.sha256(text.encode()).hexdigest(),
        'ignored_plain_explanation_characters': len(outside)})
    return value


def load_framed_json(text: str):
    try:
        return json.loads(text)
    except ValueError:
        pass
    stack, quoted, escaped = [], False, False
    for character in text:
        if quoted:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == '"':
                quoted = False
        elif character == '"':
            quoted = True
        elif character in "[{":
            stack.append("]" if character == "[" else "}")
        elif character in "]}":
            if not stack or stack.pop() != character:
                raise ValueError("Mismatched JSON container")
    if quoted or not stack or text.rstrip().endswith((",", ":")):
        raise ValueError("Not an unambiguous container-close repair")
    suffix = "".join(reversed(stack))
    result = json.loads(text + suffix)
    if not isinstance(result, dict):
        raise ValueError("Worker output must be an object")
    result.setdefault("transport_repairs", []).append({"kind": "closed_containers_at_eof", "appended": suffix})
    return result


def normalize_authoring_envelope(value: dict) -> dict:
    research = value.get("research_audit")
    if ("viewpoints" not in value and isinstance(value.get("metadata"), dict)
            and isinstance(research, dict) and isinstance(research.get("domestic_media_research"), dict)
            and isinstance(research.get("viewpoints"), dict)):
        result = copy.deepcopy(value)
        result["viewpoints"] = result["research_audit"].pop("viewpoints")
        result.setdefault("transport_repairs", []).append({"kind": "moved_unique_misnested_viewpoints",
                                                          "from": "research_audit.viewpoints", "to": "viewpoints"})
        return result
    return value
