"""Join complete reviewed monitoring records and verified public news before rendering.

The companion receipt is internal to the workflow, bound to exact workbook bytes.
It is never reconstructed from a TOP appendix or from an aggregate count.
"""
from collections import Counter
from copy import deepcopy
from datetime import date, datetime
import hashlib
import json
from pathlib import Path
import re
import shutil

from cwh_pipeline_runtime import atomic_write_json


def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def receipt_path(workbook):
    return Path(str(workbook) + '.overseas-statistics.json')


def write_basis(workbook, overseas, topics):
    payload = {'schema_version': 1, 'workbook_sha256': hashlib.sha256(Path(workbook).read_bytes()).hexdigest(),
               'status': overseas.get('status'), 'counts_reconciled': overseas.get('counts_reconciled') is True,
               'topic_titles': topics, 'counted': overseas.get('counted') or [],
               'decisions': overseas.get('decisions') or [],
               'original_reconciliation': overseas.get('reconciliation') or {}}
    atomic_write_json(receipt_path(workbook), payload)


def read_basis(workbook):
    path = receipt_path(workbook)
    if not path.is_file():
        return {}
    payload = json.loads(path.read_text('utf-8'))
    if payload.get('workbook_sha256') != hashlib.sha256(Path(workbook).read_bytes()).hexdigest():
        return {'status': 'workbook_hash_mismatch', 'counts_reconciled': False}
    return payload


def copy_basis(source, target):
    source, target = Path(source), Path(target)
    if source.resolve() == target.resolve():
        return
    src, dst = receipt_path(source), receipt_path(target)
    if src.is_file():
        shutil.copy2(src, dst)
    elif dst.is_file():
        dst.unlink()  # stale companion of the exact target being replaced


def publication_day(value):
    text = str(value or '')
    match = re.search(r'(?<!\d)(20\d{2})[-年/.](\d{1,2})[-月/.](\d{1,2})', text)
    if not match:
        # Explicit English publication dates; do not infer ambiguous numeric locales.
        for pattern, formats in [
            (r'\b\d{1,2}\s+[A-Za-z]{3,9}\s+20\d{2}\b', ['%d %B %Y', '%d %b %Y']),
            (r'\b[A-Za-z]{3,9}\s+\d{1,2},?\s+20\d{2}\b', ['%B %d %Y', '%b %d %Y']),
        ]:
            found = re.search(pattern, text)
            if found:
                for fmt in formats:
                    try:
                        return datetime.strptime(found[0].replace(',', ''), fmt).date().isoformat()
                    except ValueError:
                        continue
        return ''
    try:
        return date(*map(int, match.groups())).isoformat()
    except ValueError:
        return ''


def public_eligibility(row, period, topic_count):
    """Return a reason unless the supplied reviewed record is safe to count."""
    if row.get('meeting_relevance') is not True or row.get('count_include') is not True:
        return 'not_reviewed_for_counting'
    if row.get('publisher_class') not in {'overseas_origin_media', 'mainland_outward_media'}:
        return 'publisher_outside_scope'
    body = str(row.get('content') or '')
    if not body or row.get('full_text_read') is not True or row.get('source_text_sha256') != digest(body):
        return 'full_text_not_verified'
    if not row.get('reviewer_run_id') or row.get('publication_date_verified') is not True:
        return 'date_or_review_not_verified'
    day = publication_day(row.get('published_at'))
    proof = row.get('publication_evidence') or {}
    if not isinstance(proof, dict):
        return 'publication_date_evidence_missing'
    quote = str(proof.get('quote') or '')
    if not day or publication_day(quote) != day:
        return 'publication_date_evidence_missing'
    if proof.get('kind') == 'page_metadata':
        if quote not in [r.get('value') for r in row.get('publication_dates') or []]:
            return 'publication_metadata_mismatch'
    elif proof.get('kind') != 'page_text' or not quote or quote not in body:
        return 'publication_quote_mismatch'
    start, end = publication_day(period.get('start')), publication_day(period.get('end'))
    if not start or not end or not start <= day <= end:
        return 'outside_or_unknown_monitoring_period'
    hits = row.get('topic_hits') or []
    if any(type(i) is not int or not 1 <= i <= topic_count for i in hits):
        return 'invalid_topic_mapping'
    if not row.get('source') or not row.get('url') or not row.get('title'):
        return 'missing_source_identity'
    return ''


def unique_reports(rows):
    """No cross-publisher content/stance deduplication. Merge topic hits on copies."""
    from raw_system_workbook_pipeline import canonical_url, overseas_publisher_article_key, overseas_publisher_family, to_simplified_review_text
    def text(value):
        return re.sub(r'\s+', '', to_simplified_review_text(str(value or ''))).casefold()
    groups, indices, duplicates = [], {}, []
    for row in rows:
        clone = deepcopy(row)
        day = publication_day(row.get('published_at'))
        publisher = text(row.get('source'))
        keys = [('publisher_title_day', publisher, text(row.get('title')), day)]
        family = overseas_publisher_family(row.get('url'), row.get('source'))
        keys.append(('publisher_family_title_day', family, text(row.get('title')), day))
        if row.get('content'):
            keys.append(('same_publisher_fulltext', family, digest(text(row['content'])), day))
        url = canonical_url(row.get('url'))
        if url:
            keys.append(('url', url))
        article_key = overseas_publisher_article_key(row)
        # A /YYYYMMDD/ path segment is not an article identifier.
        token = article_key.rsplit(':', 1)[-1] if article_key else ''
        if article_key and not (len(token) == 8 and publication_day(f'{token[:4]}-{token[4:6]}-{token[6:]}')):
            keys.append(('publisher_article', article_key))
        matches = {indices[k] for k in keys if k in indices}
        if matches:
            # A bridge between previously separate identities is ambiguous.
            if len(matches) != 1:
                raise ValueError('境外报道重复关系存在冲突，需核实后回算。')
            index = next(iter(matches))
            prior = groups[index]
            if publication_day(prior.get('published_at')) != day:
                raise ValueError('同一境外报道的发布日期冲突，需核实后回算。')
            prior['topic_hits'] = sorted(set(prior.get('topic_hits') or []) | set(row.get('topic_hits') or []))
            duplicates.append({'url': row.get('url'), 'duplicate_of': prior.get('url')})
        else:
            index = len(groups)
            groups.append(clone)
        for key in keys:
            indices[key] = index
    return groups, duplicates


def counted_by_day(rows, topic_index=None):
    return Counter(publication_day(r.get('published_at')) for r in rows
                   if topic_index is None or topic_index in (r.get('topic_hits') or []))


def replace_event(event, rows, topic_index=None):
    counts = counted_by_day(rows, topic_index)
    result = deepcopy(event)
    deltas = []
    for daily in result.get('daily') or []:
        day = daily['date']
        before = int(daily.get('overseas_media') or 0)
        after = counts[day]
        daily['overseas_media'] = after
        daily['total_spread'] = int(daily.get('total_spread') or 0) + after - before
        if 'overseas_news' in (daily.get('details') or {}):
            daily['details']['overseas_news'] = after
        deltas.append({'date': day, 'before': before, 'after': after, 'delta': after-before})
    if set(counts) - {d['date'] for d in result.get('daily') or []}:
        raise ValueError('境外报道日期缺少对应统计日，不能补造其他渠道数据。')
    for key in ['overseas_media', 'total_spread']:
        value = sum(d[key] for d in result.get('daily') or [])
        result.setdefault('totals', {})[key] = value
        if key in result:
            result[key] = value
        if 'trend_totals' in result:
            result['trend_totals'][key] = value
    return result, deltas


def reconcile(data, bundle):
    """Idempotent final reconciliation; never add a delta to already updated counts."""
    system = data.get('system_data') or {}
    basis = system.get('overseas_count_basis') or {}
    audit = data.setdefault('audit', {})
    receipt = {'status': 'not_applied', 'applied': False, 'excluded': [], 'duplicates': []}
    audit['overseas_statistics_reconciliation'] = receipt
    media = bundle.get('media') or []
    if not system:
        return receipt
    def pending(reason):
        receipt.update(status='pending', reason=reason)
        if media or basis:
            message = '境外传播统计尚未最终核定：' + reason
            gaps = audit.setdefault('data_gaps', [])
            if message not in gaps:
                gaps.append(message)
            gate = audit.setdefault('acceptance', {})
            gate['ready_for_formal_delivery'] = False
            if message not in gate.setdefault('blockers', []):
                gate['blockers'].append(message)
        return receipt
    if basis.get('status') != 'ai_review_complete' or basis.get('counts_reconciled') is not True:
        return pending('缺少与本期总表绑定的完整境外审核明细，保留原有数值；不能从附录条数推算。')
    topics = [r.get('title') for r in system.get('topics') or []]
    if topics != basis.get('topic_titles'):
        return pending('境外审核明细与总表议题不一致。')
    baseline = system.get('overseas_original_statistics') or {
        'overall': deepcopy(system['overall']), 'subevents': deepcopy(system.get('subevents') or [])}
    base_rows = basis.get('counted') or []
    for index, event in [(None, baseline['overall']), *[(r['index'], r) for r in baseline['subevents']]]:
        counts = counted_by_day(base_rows, index)
        if (any(counts[d['date']] != int(d.get('overseas_media') or 0) for d in event.get('daily') or [])
                or set(counts) - {d['date'] for d in event.get('daily') or []}):
            return pending('完整审核明细与总表逐日境外量不一致。')
    included = []
    for row in media:
        reason = public_eligibility(row, system.get('monitoring_period') or {}, len(topics))
        if reason:
            receipt['excluded'].append({'url': row.get('url'), 'reason': reason})
        else:
            included.append(row)
    try:
        combined, duplicates = unique_reports([*base_rows, *included])
        overall, total_deltas = replace_event(baseline['overall'], combined)
        children, child_deltas = [], {}
        for event in baseline['subevents']:
            updated, deltas = replace_event(event, combined, event['index'])
            children.append(updated)
            child_deltas[str(event['index'])] = deltas
    except ValueError as exc:
        return pending(str(exc))
    system['overseas_original_statistics'] = baseline
    system['overall'], system['subevents'] = overall, children
    from cwh_orchestrator import apply_system_authority
    statistics, topic_stats = apply_system_authority(system, data.get('samples') or [], data.get('statistics') or {})
    statistics['by_topic'] = {r['topic']: r['spread_count'] for r in topic_stats}
    # Preserve independently computed sentiment and editorial metadata.
    numerical = {'total_samples', 'spread_count', 'domestic_media', 'self_media', 'overseas_media', 'authority'}
    old_topics = {r['topic']: r for r in data.get('topic_stats') or []}
    data['topic_stats'] = [{**old_topics.get(r['topic'], r), **{k: v for k, v in r.items() if k in numerical}} for r in topic_stats]
    data['statistics'] = statistics
    receipt.update(status='reconciled', applied=True, baseline_count=len(base_rows),
                   eligible_supplement_count=len(included), final_count=len(combined),
                   net_change=len(combined)-len(base_rows), counted=combined, duplicates=duplicates,
                   total_daily_deltas=total_deltas, child_daily_deltas=child_deltas,
                   original_raw_reconciliation=basis.get('original_reconciliation') or {})
    return receipt
